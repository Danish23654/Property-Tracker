import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import { createStore } from 'redux';
import { Provider, connect } from 'react-redux';
import PropertyDashboard from './PropertyDashboard';
import PropertyDetails from './PropertyDetails';
import AddProperty from './AddProperty';
import AddBuilder from './AddBuilder';
import EditProperty from './EditProperty';
import ViewBuilders from './ViewBuilders';
import BuilderDetails from './BuilderDetails';
import ViewProjects from './ViewProjects';
import AddProject from './AddProject';
import SignUp from './SignUp';
import EditUser from './EditUser';
import Login from './Login';
import MyBuilders from './MyBuilders';
import MyProjects from './MyProjects';
import EditBuilder from './EditBuilder';
import EditProject from './EditProject';
import AssignedProperties from './AssignedProperties';
import CreatedProperties from './CreatedProperties';
import Logout from './Logout.ts';

class App extends React.Component {
  constructor(props){
    super(props);
    this.IsLoggedIn = localStorage.getItem('UserID') != null && localStorage.getItem('UserID') != '';
  }
  handleState = () =>{
  }
  render(){
    return (
      <>
      <div style={{marginBottom: "100px"}}>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <a className="navbar-brand" href="#">Prop Tracker</a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
                    <Link className="nav-item nav-link active" to="/propertydashboard">Property Dashboard</Link>
                    
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Builder
                      </a>
                      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <Link className="dropdown-item" to="/viewbuilders">View Builders</Link>
                        {
                          this.IsLoggedIn?
                            <>
                              <Link className="dropdown-item" to="/mybuilders">My Builders</Link>
                              <div class="dropdown-divider"></div>
                            </>
                            :
                            <>
                            </>
                        }
                        <Link className="dropdown-item" to={ this.IsLoggedIn? "/addbuilder": "/login" }>Add Builder</Link>
                      </div>
                    </li>
                    
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Project
                      </a>
                      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <Link className="dropdown-item" to="/viewprojects">View Projects</Link>
                        {
                          this.IsLoggedIn?
                            <>
                            <Link className="dropdown-item" to="/myprojects">My Projects</Link>
                              <div class="dropdown-divider"></div>
                            </>
                            :
                            <>
                            </>
                        }
                        <Link className="dropdown-item" to={ this.IsLoggedIn? "/addproject": "/login" }>Add Project</Link>
                      </div>
                    </li>
                    
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Property
                      </a>
                      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        {
                          this.IsLoggedIn?
                            <>
                              <Link className="dropdown-item" to="/assignedProperties">Assigned Properties</Link>
                              <Link className="dropdown-item" to="/createdProperties">Created Properties</Link>
                              <div class="dropdown-divider"></div>
                            </>
                            :
                            <>
                            </>
                        }
                        <Link className="dropdown-item" to={ this.IsLoggedIn? "/addproperty": "/login" }>Add Property</Link>
                      </div>
                    </li>

                    <form class="form-inline my-2 my-lg-0">
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img style={{backgroundColor: "grey", width: "39px", height: "39px", marginTop: "-13px", marginBottom: "-10px"}} src="https://www.glyphicons.com/img/glyphicons/basic/2x/glyphicons-basic-4-user@2x.png"/>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          {
                            this.IsLoggedIn?
                              <>
                                <Link className="dropdown-item" to="/edituser">Edit User</Link>
                                <Link className="dropdown-item" to="/logout">Logout</Link>
                              </>
                              :
                              <>
                                <Link className="dropdown-item" to="/signup">Sign Up</Link>
                                <Link className="dropdown-item" to="/login">Login</Link>
                              </>
                          }
                        </div>
                      </li>
                    </form>
                  
            </div>
          </div>
        </nav>
        <Routes>
          <Route path="/propertydetails/:propertyID" element={<PropertyDetails/>}></Route>
          <Route path="/propertydashboard" element={<PropertyDashboard/>}></Route>
          <Route path="/addproperty" element={<AddProperty/>}></Route>
          <Route path="/editproperty/:propertyID" element={<EditProperty/>}></Route>
          <Route path="/viewbuilders" element={<ViewBuilders/>}></Route>
          <Route path="/addbuilder" element={<AddBuilder/>}></Route>
          <Route path="/builderdetails/:builderID" element={<BuilderDetails/>}></Route>
          <Route path="/viewprojects" element={<ViewProjects/>}></Route>
          <Route path="/addproject" element={<AddProject/>}></Route>
          <Route path="/signup" element={<SignUp/>}></Route>
          <Route path="/edituser" element={<EditUser/>}></Route>
          <Route path="/login" element={<Login/>}></Route>
          <Route path="/mybuilders" element={<MyBuilders/>}></Route>
          <Route path="/myprojects" element={<MyProjects/>}></Route>
          <Route path="/editbuilder/:builderID" element={<EditBuilder/>}></Route>
          <Route path="/editproject/:projectID" element={<EditProject/>}></Route>
          <Route path="/assignedProperties" element={<AssignedProperties/>}></Route>
          <Route path="/createdProperties" element={<CreatedProperties/>}></Route>
          <Route path="/logout" element={<Logout/>}></Route>
        </Routes>
      </div>
      
      <footer style={{backgroundColor: "#343a40", paddingBottom: "40px"}}></footer>
      </>
    );
  }
}



export default App;
