import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';

function PropertyDetails(){
    let [property, setProperty] = useState({});
    let {propertyID} = useParams();
    useEffect(()=>{
        fetch("https://localhost:44385/property/GetPropertyByPropertyID?PropertyID=" + propertyID)
        .then(res => res.json())
        .then(
            (result) => {
                console.log(result);
                setProperty(result);
            },
            (error) => {
            }
        )
    },[])
    return(
        <div className="row">
            <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1">
                {
                    property.project != null? 
                        <div style={{marginBottom: "14px"}}>
                            <span style={{ fontSize: "20px"}}>{property.project.projectName} by </span>
                            <span style={{ fontSize: "23px", fontWeight: "bold"}}>{property.project.builder.builderName}</span>
                            <span style={{float: "right"}}>
                                <Link to={"/editproperty/" + propertyID}>
                                    <button className='btn btn-warning'>Update</button>
                                </Link>
                            </span>
                        </div>
                    : <></>
                }
                <div className="grey-background" style={{ borderRadius: "4px" }}>
                    <h3 style={{ paddingTop: "5px", paddingBottom: "8px" }}>
                        &nbsp;&nbsp;&nbsp;Overview
                    </h3>
                </div>
                {
                    property.propertyType != null?
                        <div className='row'>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-2 col-md-2 col-sm-4 col-xs-6">Type</td>
                                            <td className="col-lg-10 col-md-10 col-sm-8 col-xs-6">{property.propertyType.propertyTypeName}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-2 col-md-2 col-sm-4 col-xs-6">Price</td>
                                            <td className="col-lg-10 col-md-10 col-sm-8 col-xs-6">{property.price}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-2 col-md-2 col-sm-4 col-xs-6">Location</td>
                                            <td className="col-lg-10 col-md-10 col-sm-8 col-xs-6">{property.project.block.blockName}, {property.project.block.area.areaName}, {property.project.block.area.city.cityName}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-2 col-md-2 col-sm-4 col-xs-6">Bathrooms</td>
                                            <td className="col-lg-10 col-md-10 col-sm-8 col-xs-6">{property.noOfBathrooms}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Area</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.area} Sq. Yards</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Bedrooms</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.noOfBedrooms}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Updated</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.lastModified}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Added</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.dateCreated}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        :
                        <></>
                    
                }
                {
                    property.user != null && property.user.firstName != null?
                    <>
                        <div className="grey-background" style={{ borderRadius: "4px" }}>
                            <h3 style={{ paddingTop: "5px", paddingBottom: "8px" }}>
                                &nbsp;&nbsp;&nbsp;Owner
                            </h3>
                        </div>
                        <div className='row'>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Name</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.user.firstName} {property.user.lastName}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Phone Number</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.user.phoneNumber}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">CNIC</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.user.cnic.substring(0, 5) + "-" + property.user.cnic.substring(5, 12) + "-" + property.user.cnic.substring(12, 13)}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Email Address</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.user.emailAddress}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </>:
                    <></>
                
                }
                {
                    property.propertyType != null?
                        <>
                            <div className="grey-background" style={{ borderRadius: "4px" }}>
                                <h3 style={{ paddingTop: "5px", paddingBottom: "8px" }}>
                                    &nbsp;&nbsp;&nbsp;Description
                                </h3>
                            </div>
                            <div className='row'>
                                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                        <tbody>
                                            <tr>
                                                <td className="col-lg-10 col-md-10 col-sm-8 col-xs-6">
                                                    {property.description}
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </>
                        :
                        <></>
                }
                {
                    property != null && property.paymentPlan != null && property.paymentPlan.paymentPlanID != null?
                        <>
                        
                        <div className="grey-background" style={{ borderRadius: "4px" }}>
                                <h3 style={{ paddingTop: "5px", paddingBottom: "8px" }}>
                                    &nbsp;&nbsp;&nbsp;Payment Plan
                                </h3>
                            </div>
                        <div className='row'>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Payment Plan</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.paymentPlan.paymentPlanType.paymentPlanTypeName}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Down Payment</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.paymentPlan.downPayment}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Paid Installments</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.paymentPlan.paidInstallments}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table style={{fontSize: "13.5px"}} className="table table-striped table-sm">
                                    
                                    <tbody>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Loan Amount</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.paymentPlan.loanAmount}</td>
                                        </tr>
                                        <tr>
                                            <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Total Installments</td>
                                            <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{property.paymentPlan.totalInstallments}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        </>
                        :
                        <></>
                }
            </div>
        </div>
    );
}

// class DisplayProperty extends React.Component{
//     constructor(props){
//         super(props);
//         this.state = { property: {} }
//     }
//     componentDidMount(){
//         fetch("https://localhost:44385/property/GetPropertyByPropertyID?PropertyID=" + this.props.PropertyID)
//         .then(res => res.json())
//         .then(
//             (result) => {
//                 console.log(result);
//                 this.setState({
//                     property: result
//                 });
//             },
//             (error) => {
//             }
//         )
//     }
//     render(){
//         return(
//             <div className="row">
//                 <div className='col-lg-2 col-md-1 col-sm-1 col-xs-1'>
                    
//                 </div>
//                 <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-2 offset-sm-2 offset-xs-1">
//                         {
//                             this.state.property.project != null? 
//                                 <>
//                                     <span style={{ fontSize: "20px"}}>{this.state.property.project.projectName} by </span>
//                                     <span style={{ fontSize: "23px", fontWeight: "bold"}}>{this.state.property.project.builder.builderName}</span>
//                                 </>
//                             : <></>
//                         }
//                         <div className="grey-background" style={{ borderRadius: "4px" }}>
//                             <h3 style={{ paddingTop: "5px", paddingBottom: "8px" }}>
//                                 &nbsp;&nbsp;&nbsp;Overview
//                             </h3>
//                         </div>
//                         {
//                             this.state.property.propertyType != null?
//                                 <>
//                                     <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
//                                         <table className="table table-striped ">
                                            
//                                             <tbody>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Type</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.propertyType.propertyTypeName}</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Price</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.price}</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Location</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.project.block.blockName}, {this.state.property.project.block.area.areaName}, {this.state.property.project.block.area.city.cityName}</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Bathrooms</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.noOfBathrooms}</td>
//                                                 </tr>
//                                             </tbody>
//                                         </table>
//                                     </div>
//                                     <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
//                                         <table className="table table-striped ">
                                            
//                                             <tbody>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Area</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.area} Sq. Yards</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Bedrooms</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.noOfBedrooms}</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Updated</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.lastModified}</td>
//                                                 </tr>
//                                                 <tr>
//                                                     <td className="col-lg-3 col-md-3 col-sm-4 col-xs-6">Added</td>
//                                                     <td className="col-lg-9 col-md-9 col-sm-8 col-xs-6">{this.state.property.dateCreated}</td>
//                                                 </tr>
//                                             </tbody>
//                                         </table>
//                                     </div>
//                                 </>
//                                 :
//                                 <></>
                            
//                         }
//                         {
//                             this.state.property.propertyType != null?
//                                 <>
//                                     <div className="col-lg-8 col-md-8 col-sm-8 col-xs-10">
//                                         <table className="table table-striped ">
//                                             <h4>Description</h4>
//                                             {this.state.property.description}
//                                         </table>
//                                     </div>
//                                 </>
//                                 :
//                                 <></>
//                         }
//                 </div>
//             </div>
//         );
//     }
// }
export default PropertyDetails;
