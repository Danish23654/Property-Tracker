import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';


function EditProject(){ 
    let navigate = useNavigate();
    let {projectID} = useParams();
    let normal = false;
    let [state, setState] = useState({
        ProjectName: "",
        Description: "",
        BuilderID: "",
        BuilderList: null,
        BlockID: "",
        BlockList: null,
        AreaID: "",
        AreaList: null,
        CityID: "",
        CityList: null,
        UserID: localStorage.getItem("UserID"),
        CityListUpdated: false,
        TempAreaID: "",
        TempBlockID: "",
        BuilderUpdate: false,
        PropertyID: 0,
        normal: false
    });


    useEffect(()=>{
        if(state.normal == false){
            fetch("https://localhost:44385/property/getallcities")
            .then(res => res.json())
            .then(
                (result) => {
                    setState({
                        ...state,
                        CityList: result,
                        CityListUpdated: true
                    });
                },
                (error) => {
                }
            );
            
        }
    }, [])

    useEffect(()=>{
        if(state.normal == false && state.CityID != ""){
            document.querySelectorAll('#CityID option').forEach(answer => {     
                if(answer.value == state.CityID){
                    answer.selected = 'selected';
                }    
            })
            
            fetch("https://localhost:44385/property/getAllAreasByCityID?CityID=" + state.CityID)
            .then(res => res.json())
            .then(
                (result) => {
                    let PlaceholderResult = [{areaID: -1, areaName: 'Not Available', city: null}];
                    setState({
                        ...state,
                        AreaID: state.TempAreaID,
                        AreaList: result.length > 0? result: PlaceholderResult
                    });
                },
                (error) => {
                }
            )
            
        }
    }, [state.CityID]);

    useEffect(()=>{
        if(state.normal  == false && state.AreaID != ""){
            document.querySelectorAll('#AreaID option').forEach(answer => {     
                if(answer.value == state.AreaID){
                    answer.selected = 'selected';
                }    
            })
            
            fetch("https://localhost:44385/property/getAllBlocksByAreaID?AreaID=" + state.AreaID)
            .then(res => res.json())
            .then(
                (result) => {
                    let PlaceholderResult = [{blockID: -1, blockName: 'Not Available', area: null}];
                    setState({
                        ...state,
                        BlockID: state.TempBlockID,
                        BlockList: result.length > 0? result: PlaceholderResult
                    });
                },
                (error) => {
                }
            )
        }
    }, [state.AreaID]);

    useEffect(()=> {
        if(state.normal  == true)
            fetch("https://localhost:44385/property/GetAllBuilderNamesByUserID?UserID=" + state.UserID)
            .then(res => res.json())
            .then(
                (result) => {
                    let PlaceholderResult = [{builderID: -1, builderName: 'Not Available'}];
                    setState({
                        ...state,
                        BuilderList: result.length > 0? result: PlaceholderResult,
                        BuilderUpdate: true
                    });
                },
                (error) => {
                }
            )
    }, [state.normal]);

    useEffect(()=>{
        if(state.BuilderUpdate == true){
            document.querySelectorAll('#BuilderID option').forEach(answer => {     
                if(answer.value == state.TempBuilderID){
                    answer.selected = 'selected';
                    setState({...state, BuilderID: state.TempBuilderID, BuilderUpdate: false });
                }    
            })
        }
    }, [state.BuilderUpdate])
    
    useEffect(()=>{
        if(state.normal == false && state.AreaID != ""){
            document.querySelectorAll('#BlockID option').forEach(answer => {     
                if(answer.value == state.BlockID){
                    answer.selected = 'selected';
                    setState({...state, normal: true });
                }    
            })
        }
    }, [state.BlockID]);

    // useEffect(()=>{
    //     if(normal == false && state.AreaID != ""){
    //         console.log("Area");
    //         console.log(state);
    //         document.querySelectorAll('#AreaID option').forEach(answer => {     
    //             if(answer.value == state.AreaID){
    //                 answer.selected = 'selected';
    //             }    
    //         })
    //     }
    // }, [state.BlockID]);

    useEffect(()=>{
        if(state.CityListUpdated == true){
            fetch("https://localhost:44385/property/GetProjectByProjectID?ProjectID="+ projectID)
            .then(res => res.json())
            .then(
                (result) => {
                    setState({ 
                        ...state, 
                        ProjectName: result.projectName,
                        Description: result.description,
                        CityID: result.block.area.city.cityID,
                        TempAreaID: result.block.area.areaID,
                        TempBlockID: result.block.blockID,
                        TempBuilderID: result.builder.builderID,
                        CityListUpdated: false
                    })
                },
                (error) => {
                }
            );
        }
        
    }, [state.CityListUpdated]);
    
    useEffect(()=>{
        if(state.normal  == true && state.CityID != ""){
            getAreas();
        }
    }, [state.CityID]);

    // useEffect(()=>{
    //     if(normal == true){
    //         console.log(state.AreaID);
    //         getBlocks();
    //     }
    // }, [state.AreaID]);

    useEffect(()=>{
        if(state.normal  == true){
            getBlocks();
        }
    }, [state.AreaID]);

    function getAreas(){
        fetch("https://localhost:44385/property/getAllAreasByCityID?CityID=" + state.CityID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{areaID: -1, areaName: 'Not Available', city: null}];
                setState({
                    ...state,
                    AreaID: result.length > 0? result[0].areaID: PlaceholderResult[0].areaID,
                    AreaList: result.length > 0? result: PlaceholderResult
                });
            },
            (error) => {
            }
        )
    }
    function getBlocks(){
        fetch("https://localhost:44385/property/getAllBlocksByAreaID?AreaID=" + state.AreaID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{blockID: -1, blockName: 'Not Available', area: null}];
                setState({
                    ...state,
                    BlockID: result.length > 0? result[0].blockID: PlaceholderResult[0].blockID,
                    BlockList: result.length > 0? result: PlaceholderResult
                });
            },
            (error) => {
            }
        )
    }
    function handle(e){
        e.preventDefault();
        //console.log(e.target.children[0].name);
        setState({...state, [e.target.name]: e.target.value});
        
    }
    function submit(e){
        e.preventDefault();
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == '' && answer.id != "CNIC"){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }       
        })
        document.querySelectorAll('form select').forEach(answer => {     
            if(answer.value == '-1'){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }            
        })
        document.querySelectorAll('form textarea').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }           
        })
        if(count == 0){
            updateProject();
        }
    }

    function updateProject(){
        
        let p = new BusinessModelParser().MapStateToProperty(state);
        //console.log(p);
        
        fetch("https://localhost:44385/property/GetAllProjectNamesByBuilderID?BuilderID=" + state.BuilderID + "&ProjectID=" + projectID)
        .then(res => res.json())
        .then(
            async (result) => {
                let count = 0;
                await result.forEach((Project) => {
                    if(Project.projectName == state.ProjectName){
                        count = 1;
                        document.getElementById("ProjectNameError").style.display = 'block';
                    }
                })
                if(count == 0){
                    let p = await new BusinessModelParser().MapStateToProject(state);
                    p.projectID = projectID;
                    fetch("https://localhost:44385/property/UpdateProject?json=" + JSON.stringify(p), {
                        method: 'POST'
                    })
                    .then(res => res.json())
                    .then(
                        (result) => {
                        },
                        (error) => {
                            navigate("/myprojects");
                        }
                    )
                }
            },
            (error) => {
            }
        )
        // fetch("https://localhost:44385/property/InsertProject?json=" + JSON.stringify(p), {
        //     method: 'POST'
        // }).then(res => res.json()).then(
        //     async (result) => {
        //         await fetch("https://localhost:44385/property/InsertProject?json=" + JSON.stringify(p), {
        //             method: 'POST'
        //         })
        //         .then(res => res.json())
        //         .then(
        //             (result) => {
        
        //             },
        //             (error) => {
        //             }
        //         )
        //     },
        //     (error) => {

        //     }
        // )
    }

    return(
        <div className="row">
            <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1">
            <form onSubmit={submit}>
                <div className="form-row">
                    <div className="form-group col-md-6">
                        <label htmlFor="ProjectName">Project Name</label>
                        <input id="ProjectName" className="form-control" name="ProjectName" type="text" value={state.ProjectName} onChange={handle}/>
                        <p style={{color: "red", display: "none"}} id="ProjectNameError">Project Name already exist under selected Builder</p>
                    </div>
                    <div className="form-group col-md-6">
                        <label htmlFor="CityID">City</label>
                        <select id="CityID" className="form-control" name="CityID" onChange={handle}>
                            {
                                state.CityList != null?
                                    state.CityList.map((City) =>
                                        <option key={City.cityID} value={City.cityID}>{City.cityName}</option>
                                    ): "Loading"
                            }
                        </select>
                    </div>
                </div>
                <div className="form-row">
                    <div className="form-group col-md-6">
                        <label htmlFor="AreaID">Area</label>
                        <select id="AreaID" className="form-control" name="AreaID" onChange={handle}>
                            {
                                state.AreaList != null?
                                    state.AreaList.map((Area) =>
                                        <option key={Area.areaID} value={Area.areaID}>{Area.areaName}</option>
                                    ): <option value="" disabled selected>City is not selcted</option>
                            }
                        </select>
                    </div>
                    <div className="form-group col-md-6">
                        <label htmlFor="BlockID">Block</label>
                        <select id="BlockID" className="form-control" name="BlockID" onChange={handle}>
                            {
                                state.BlockList != null?
                                    state.BlockList.map((Block) =>
                                        <option key={Block.blockID} value={Block.blockID}>{Block.blockName}</option>
                                    ): <option value="" disabled selected>Area is not selected</option>
                            }
                        </select>
                    </div>
                </div>
                <div className="form-row">
                    <div className="form-group col-md-6">
                        <label htmlFor="BuilderID">Builder</label>
                        <select id="BuilderID" className="form-control" name="BuilderID" onChange={handle}>
                            {
                                state.BuilderList != null?
                                    state.BuilderList.map((Builder) =>
                                        <option key={Builder.builderID} value={Builder.builderID}>{Builder.builderName}</option>
                                    ): "Loading"
                            }
                        </select>
                    </div>
                </div>
                <div className="form-row">    
                    <label htmlFor="Description">Description</label>
                    <textarea id="Description" name="Description" className="form-control" value={state.Description} onChange={handle}/>
                </div>
                <div className="form-row">    
                <input  className="btn btn-primary" type="submit" value="submit"/>
                </div>
            </form>
            </div>
        </div>
    )
}

export default EditProject;
