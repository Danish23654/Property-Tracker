export class Property
{
    propertyID: number;
    propertyNumber: string;
    noOfBathrooms: number;
    noOfBedrooms: number;
    area: number;
    propertyType: PropertyType;
    floor: number;
    lastModified: string;
    dateCreated: string;
    description: string;
    project: Project; 
    //AgentID;
    user: User;
    price: number;
    paymentPlan: PaymentPlan;
}

export class PaymentPlan
{
    paymentPlanID: number;
    propertyID: number;
    userID: number;
    paymentPlanType: PaymentPlanType;
    downPayment: number;
    loanAmount: number;
    totalInstallments: number;
    paidInstallments: number;
    actualPrice: number;
}

export class PaymentPlanType
{
    paymentPlanTypeID: number;
    paymentPlanTypeName: string;
}

export class User
{
    userID: number;
    emailAddress: string;
    cnic: string;
    firstName: string;
    lastName: string;
    password: string;
    mobileNumber: string;
}

export class Builder 
{
    builderID: number;
    builderName: string;
    description: string;
    user: User;
    mobileNumber: string;
}

export class PropertyType 
{
    propertyTypeID: number;
    propertyTypeName: string;
}

export class Project
{
    projectID: number;
    projectName: string;
    builder: Builder;
    block: Block;
    description: string;
    mobileNumber: string;
}

export class Block
{
    blockID: number;
    blockName: string;
    area: Area;
}

export class Area
{
    areaID: number;
    areaName: string;
    city: City;
}

export class City
{
    cityID: number;
    cityName: string;
}


export class BusinessModelParser{
    MapStateToProperty(state): Property{
        let property = new Property();
        property.propertyNumber = state.PropertyNumber;
        property.noOfBathrooms = state.NoOfBathrooms;
        property.noOfBedrooms = state.NoOfBedrooms;
        property.area = state.Area;
        property.floor = state.Floor;
        property.description = state.Description;
        property.price = state.price;

        property.propertyType = new PropertyType();
        property.propertyType.propertyTypeID = state.PropertyTypeID;
        console.log(state);
        property.project = new Project();
        property.project.projectID = state.ProjectID;

        property.project.builder = new Builder();
        property.project.builder.builderID = state.BuilderID;
        property.project.block = new Block();
        property.project.block.blockID = state.BlockID;
        property.project.block.area = new Area();
        property.project.block.area.areaID = state.AreaID;
        property.project.block.area.city = new City();
        property.project.block.area.city.cityID = state.CityID;

        property.user = new User();
        property.user.cnic = state.CNIC;

        property.propertyID = state.propertyID;
        property.paymentPlan = new PaymentPlan();
        property.paymentPlan.paymentPlanID = state.paymentPlanID;
        property.paymentPlan.propertyID = state.propertyID;
        property.paymentPlan.userID = 0;
        property.paymentPlan.paymentPlanType = new PaymentPlanType();
        property.paymentPlan.paymentPlanType.paymentPlanTypeID = state.paymentPlanTypeID;
        property.paymentPlan.downPayment = state.downPayment;
        property.paymentPlan.loanAmount = state.loanAmount;
        property.paymentPlan.totalInstallments = state.totalInstallments;
        property.paymentPlan.paidInstallments = state.paidInstallments;
        property.paymentPlan.actualPrice = state.price;

        return property;
    }
    
    async MapPropertyToState(model: Property){
        let CityList = await this.GetAllCities();
        let AreaList = await this.GetAllAreasByCityID(model.project.block.area.city.cityID);
        let BlockList = await this.GetAllBlocksByAreaID(model.project.block.area.areaID);
        let UserID = localStorage.getItem("UserID");
        let BuilderList = await this.GetAllBuildersByBlockID(model.project.block.blockID, parseInt(UserID == null? "": UserID));
        let ProjectList = await this.GetAllProjectsByBuilderID(model.project.builder.builderID, model.project.block.blockID);
        let PropertyTypeList = await this.GetAllPropertyTypes();
        return {
            propertyID: model.propertyID,
            PropertyNumber: model.propertyNumber, 
            NoOfBathrooms: model.noOfBathrooms, 
            NoOfBedrooms: model.noOfBedrooms, 
            Area: model.area,
            PropertyTypeID: model.propertyType.propertyTypeID,
            PropertyTypeList: PropertyTypeList,
            Floor: model.floor,
            Description: model.description,
            ProjectID: model.project.projectID,
            ProjectList: ProjectList,
            Price: model.price,
            BuilderID: model.project.builder.builderID,
            BuilderList: BuilderList,
            BlockID: model.project.block.blockID,
            BlockList: BlockList,
            AreaID: model.project.block.area.areaID,
            AreaList: AreaList,
            CityID: model.project.block.area.city.cityID,
            CityList: CityList,
            EditCityID: model.project.block.area.city.cityID,
            EditAreaID: model.project.block.area.areaID,
            EditProjectID: model.project.projectID,
            EditBlockID: model.project.block.blockID,
            EditBuilderID: model.project.builder.builderID,
            EditPropertyTypeID: model.propertyType.propertyTypeID,
            CNIC: model.user.cnic != null? model.user.cnic.substring(0, 5) + "-" + model.user.cnic.substring(5, 12) + "-" + model.user.cnic.substring(12, 13): "",
            Count: 0,
            paymentPlanID: model.paymentPlan.paymentPlanID,
            paymentPlanTypeID: model.paymentPlan.paymentPlanType.paymentPlanTypeID,
            downPayment: model.paymentPlan.downPayment,
            loanAmount: model.paymentPlan.loanAmount,
            totalInstallments: model.paymentPlan.totalInstallments,
            paidInstallments: model.paymentPlan.paidInstallments,
        };
    }
    
    async GetAllCities(){
        let CityList: City[] = [];
        await fetch("https://localhost:44385/property/getAllCities")
        .then(res => res.json())
        .then(
            (result) => {
                CityList = result;
            },
            (error) => {
            }
        )
        return CityList;
    }
    async GetCNICByUserID(UserID){
        let CNIC: string = "";
        await fetch("https://localhost:44385/property/GetCNICByUserID?UserID=" + UserID)
        .then(res => res.json())
        .then(
            (result) => {
                CNIC = result;
            },
            (error) => {
            }
        )
        return CNIC;
    }
    async GetAllAreasByCityID(CityID){
        let AreaList: Area[] = [];
        await fetch("https://localhost:44385/property/GetAllAreasByCityID?CityID=" + CityID)
        .then(res => res.json())
        .then(
            (result) => {
                AreaList = result;
            },
            (error) => {
            }
        )
        return AreaList;
    }
    async GetAllBlocksByAreaID(AreaID){
        let BlockList: Block[] = [];
        await fetch("https://localhost:44385/property/GetAllBlocksByAreaID?AreaID=" + AreaID)
        .then(res => res.json())
        .then(
            (result) => {
                BlockList = result;
            },
            (error) => {
            }
        )
        return BlockList;
    }
    async GetAllBuildersByBlockID(BlockID, UserID = 0){
        let BuilderList: Builder[] = [];
        await fetch("https://localhost:44385/property/GetAllBuildersByBlockID?BlockID=" + BlockID + "&UserID=" + UserID)
        .then(res => res.json())
        .then(
            (result) => {
                BuilderList = result;
            },
            (error) => {
            }
        )
        return BuilderList;
    }
    async GetAllProjectsByBuilderID(BuilderID, BlockID = 0){
        let ProjectList: Project[] = [];
        await fetch("https://localhost:44385/property/GetAllProjectsByBuilder?BuilderID=" + BuilderID + "&BlockID=" + BlockID)
        .then(res => res.json())
        .then(
            (result) => {
                ProjectList = result;
            },
            (error) => {
            }
        )
        return ProjectList;
    }
    async GetAllPropertyTypes(){
        let PropertyTypeList: PropertyType[] = [];
        await fetch("https://localhost:44385/property/GetAllPropertyTypes")
        .then(res => res.json())
        .then(
            (result) => {
                PropertyTypeList = result;
            },
            (error) => {
            }
        )
        return PropertyTypeList;
    }

    MapStateToBuilder(state): Builder{
        let builder = new Builder();
        builder.builderName = state.builderName;
        builder.description = state.description;
        builder.user = new User();
        builder.user.userID = state.userID;
        builder.builderID = state.builderID;
        builder.mobileNumber = state.mobileNumber;
        return builder;
    }

    MapStateToProject(state): Project{
        let project = new Project();
        project.projectName = state.ProjectName;
        project.builder = new Builder();
        project.builder.builderID = state.BuilderID;
        project.block = new Block();
        project.block.blockID = state.BlockID;
        project.description = state.Description;
        project.mobileNumber = state.MobileNumber;
        return project;
    }

    async IsCNICExist(CNIC, UserID=0){
        let IsExist: boolean = false;
        await fetch("https://localhost:44385/property/IsCNICExist?CNIC=" + CNIC.replace("-", "").replace("-", "") + "&UserID=" + UserID)
        .then(res => res.json())
        .then(
            async (result) => {
                //console.log(result);
                IsExist = await result;
            },
            (error) => {
            }
        )
        return IsExist;
    }
    
    MapStateToUser(state): User{
        let user = new User();
        user.firstName = state.FirstName;
        user.lastName = state.LastName;
        user.emailAddress = state.EmailAddress;
        user.cnic = state.CNIC;
        user.password = state.Password;
        user.mobileNumber = state.MobileNumber;
        return user;
    }
    async GetUserByUserID(UserID){
        let user: User[] = [];
        await fetch("https://localhost:44385/property/GetUserByUserID?UserID="+ UserID)
        .then(res => res.json())
        .then(
            (result) => {
                user = result;
            },
            (error) => {
            }
        )
        return user;
    }

    async IsValidLogin(EmailAddress, Password){
        let IsExist: boolean = false;
        await fetch("https://localhost:44385/property/IsValidLogin?EmailAddress=" + EmailAddress + "&Password=" + Password)
        .then(res => res.json())
        .then(
            async (result) => {
                //console.log(result);
                IsExist = await result;
            },
            (error) => {
            }
        )
        return IsExist;
    }

    async GetUserIDByEmailAddress(EmailAddress){
        let UserID;
        await fetch("https://localhost:44385/property/GetUserIDByEmailAddress?EmailAddress=" + EmailAddress)
        .then(res => res.json())
        .then(
            async (result) => {
                //console.log(result);
                UserID = await result;
            },
            (error) => {
            }
        )
        return UserID;
    }
}