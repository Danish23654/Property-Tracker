import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import './PropertyDashboard.css'

class PropertyDashboard extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { properties: [] };
    }
    componentDidMount(props){
        fetch("https://localhost:44385/property/getallproperties" + (this.props.AssignedProperties? "?UserID="+ localStorage.getItem("UserID"): "") + (this.props.CreatedProperties? "?CreatedByUserID="+ localStorage.getItem("UserID"): "") )
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    properties: result
                });
                console.log(result);
            },
            (error) => {
            }
        )
    }

  render(){
    return(
      <>
          <div class="row">
            <div className="col-md-10 offset-md-1">
                    <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Bed(s)</th>
                        <th scope="col">Bath(s)</th>
                        <th scope="col">Floor</th>
                        <th scope="col">Sq. Yards</th>
                        <th scope="col">Price</th>
                        <th scope="col">Location</th>
                        <th scope="col">Project</th>
                        {
                            this.props.CreatedProperties? 
                                <th scope="col"></th>
                                :<></>
                        }
                      </tr>
                    </thead>
                    <tbody>
                    {this.state.properties.map((property) =>
                      <tr>
                        <td><Link to={"/propertydetails/" + property.propertyID }>{property.propertyNumber}</Link></td>
                        <td>{property.noOfBedrooms}</td>
                        <td>{property.noOfBathrooms}</td>
                        <td>{property.floor}</td>
                        <td>{property.area}</td>
                        <td>Rs {property.price}</td>
                        <td>{property.project.block.blockName}, {property.project.block.area.areaName}, {property.project.block.area.city.cityName}</td>
                        <td>{property.project.projectName} by {property.project.builder.builderName}</td>
                        {
                            this.props.CreatedProperties? 
                                <td>
                                    <Link to={"/editproperty/" + property.propertyID}>
                                        <button className='btn btn-warning'>Update</button>
                                    </Link>
                                </td>
                                :<></>
                        }
                      </tr>
                    )}
                    </tbody>
                  </table>
            </div>
                {/* <div className='custom-card col-lg-8 offset-2 col-md-8 col-sm-8 col-xs-8'>
                    <Link to={"/propertydetails/" + property.propertyID} style={{textDecoration: "none"}}>
                        <div className='row'>
                            <div className='col-lg-3  col-md-3 col-sm-4 col-xs-4'>
                            </div>
                            <div className='col-lg-9  col-md-9 col-sm-8 col-xs-8'>
                                PKR <span style={ {fontWeight: "bold", fontSize: "25px"}}>{property.price}</span>
                                <br></br>
                                {property.project.block.blockName}, {property.project.block.area.areaName}, {property.project.block.area.city.cityName}
                                <br></br>
                                <span class="glyphicon glyphicon-bed"></span> {property.noOfBedrooms}&nbsp;&nbsp;
                                <span class="glyphicon glyphicon-tint"></span> {property.noOfBathrooms}&nbsp;&nbsp;
                                <span class="glyphicon glyphicon-scale"></span> {property.area} Sq. Yards&nbsp;
                                <br></br>
                                {property.description}
                                <br></br><br></br>
                                {property.project.projectName} by <b>{property.project.builder.builderName}</b>
                            </div>
                        </div>
                    </Link>
                </div> */}
        </div>
        
        {
          this.state.properties.length == 0? 
          <div class="row">
            <div className="col-md-10 offset-md-1">
              <div class="alert alert-primary" role="alert">
                  No Property found!
              </div>
            </div>
          </div>
          : <></>
        }
      </>
    );
  };
}
export default PropertyDashboard;
