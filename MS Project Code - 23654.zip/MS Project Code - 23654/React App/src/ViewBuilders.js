import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';

class ViewBuilders extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { builders: [] };
        this.userID = this.props.userID;
        console.log(this.userID);
    }
    componentDidMount(){
        console.log(this.props.userID)
        fetch("https://localhost:44385/property/getallbuilders?UserID=" + this.userID)
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    builders: result
                }, () => {
                    console.log(this.state.builders);
                });
            },
            (error) => {
            }
        )
    }

    fetchCities = (projects) => {
        let arr = [];
        projects.forEach(async (project)=>{
            await arr.push(project.block.area.city.cityName);
        });
        return [...new Set(arr)].sort();
    }

  render() {
    return(
      <>
        <div className="row">
            <div className="col-md-8 offset-md-2">
                {/* <div className="form-group col-md-6">
                    <label htmlFor="PropertyTypeID">Property Type</label>
                    <select id="PropertyTypeID" className="form-control" name="PropertyTypeID" onChange={this.handle}>
                        {
                            this.state.PropertyTypeList != null?
                                this.state.PropertyTypeList.map((PropertyType) =>
                                    <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                ): "Loading"
                        }
                    </select>
                </div> */}
                <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}>
                    {
                        this.props.userID != null? 
                            <strong>My Builders</strong>
                            :<strong>Builders</strong>
                    }
                </div>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Builder Name</th>
                            <th scope="col">No. of Projects</th>
                            <th scope="col">No. of Cities</th>
                                {
                                    this.userID != undefined? 
                                        <th></th>:
                                        <></>
                                }
                        </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.builders.map((builder, index) =>
                            <tr>
                                <th scope="row">{index + 1}</th>
                                <td><Link to={"/builderdetails/" + builder.builderID}>{builder.builderName}</Link></td>
                                <td>{builder.projects.length == 0? '-': builder.projects.length }</td>
                                <td>
                                    {
                                        builder.projects.length == 0? '-':
                                            
                                        this.fetchCities(builder.projects).map((city, index1) => 
                                            <>
                                                {city}
                                                {index1 < this.fetchCities(builder.projects).length - 1? ', ': ''}
                                            </>
                                        )
                                        // builder.projects.map((project, index1) => 
                                        //     <>
                                        //         {project.block.area.city.cityName}
                                        //         {index1 < builder.projects.length - 1? ', ': ''}
                                        //     </>
                                        // )
                                    }
                                </td>
                                {
                                    this.userID != undefined? 
                                        <td>
                                            <Link to={"/editbuilder/" + builder.builderID}>
                                                <button type="button" class="btn btn-primary">
                                                    Edit
                                                </button>
                                            </Link>
                                        </td>:
                                        <></>
                                }
                            </tr>
                        )
                    }
                    </tbody>
                </table>
                {
                    (this.state.builders.length == 0 || this.state.builders == null) && this.props.userID == undefined? 
                    <div class="alert alert-primary" role="alert">
                        There are no Builders into the system.
                    </div>: 
                    this.state.builders.length == 0 || this.state.builders == null? 
                    <div class="alert alert-primary" role="alert">
                        You do not have Builder(s)
                    </div>: <></>
                }
            </div>
        </div>
      </>
    );
  };
}
export default ViewBuilders;
