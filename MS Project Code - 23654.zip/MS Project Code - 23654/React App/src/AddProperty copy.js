import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';


class AddProperty extends React.Component{
    constructor(){
        super();
        this.BusinessModelParser = new BusinessModelParser();
        this.state = { 
            PropertyNumber: "", 
            NoOfBathrooms: 0, 
            NoOfBedrooms: 0, 
            Area: 0,
            PropertTypeID: "",
            PropertyTypeList: null,
            Floor: 0,
            Description: "",
            ProjectID: "",
            ProjectList: null,
            Price: 0,
            BuilderID: "",
            BuilderList: null,
            BlockID: "",
            BlockList: null,
            AreaID: "",
            AreaList: null,
            CityID: "",
            CityList: null,
            InsertSuccess: false,
            ValidCNIC: true,
            CNIC: "",
            UserID: localStorage.getItem('UserID')
        };
    }
    componentDidMount(){
        fetch("https://localhost:44385/property/getallcities")
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    ...this.state,
                    CityID: result[0].cityID,
                    CityList: result
                }, 
                () => {
                    this.getAreas();
                });
            },
            (error) => {
            }
        )
        this.getPropertyTypes();
    }
    getAreas = () => {
        fetch("https://localhost:44385/property/getAllAreasByCityID?CityID=" + this.state.CityID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{areaID: -1, areaName: 'Not Available', city: null}];
                this.setState({
                    ...this.state,
                    AreaID: result.length > 0? result[0].areaID: PlaceholderResult[0].areaID,
                    AreaList: result.length > 0? result: PlaceholderResult
                }, () => {
                    this.getBlocks();
                });
            },
            (error) => {
            }
        )
    }
    getBlocks = () => {
        fetch("https://localhost:44385/property/getAllBlocksByAreaID?AreaID=" + this.state.AreaID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{blockID: -1, blockName: 'Not Available', area: null}];
                this.setState({
                    ...this.state,
                    BlockID: result.length > 0? result[0].blockID: PlaceholderResult[0].blockID,
                    BlockList: result.length > 0? result: PlaceholderResult
                }, () => {
                    this.getBuilders();
                });
            },
            (error) => {
            }
        )
    }
    getBuilders = () => {
        fetch("https://localhost:44385/property/GetAllBuildersByBlockID?BlockID=" + this.state.BlockID + "&UserID=" + this.state.UserID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{builderID: -1, builderName: 'Not Available'}];
                this.setState({
                    ...this.state,
                    BuilderID: result.length > 0? result[0].builderID: PlaceholderResult[0].builderID,
                    BuilderList: result.length > 0? result: PlaceholderResult
                }, () => {
                    this.getProjects();
                });
            },
            (error) => {
            }
        )
    }
    getProjects = () => {
        fetch("https://localhost:44385/property/getAllProjectsByBuilder?BuilderID=" + this.state.BuilderID + "&BlockID=" + this.state.BlockID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{projectID: -1, projectName: 'Not Available'}];
                this.setState({
                    ...this.state,
                    ProjectID: result.length > 0? result[0].projectID: PlaceholderResult[0].projectID,
                    ProjectList: result.length > 0? result: PlaceholderResult
                });
            },
            (error) => {
            }
        )
    }
    getPropertyTypes = () => {
        fetch("https://localhost:44385/property/getAllPropertyTypes")
        .then(res => res.json())
        .then(
            (result) => {
                console.log(result);
                this.setState({
                    ...this.state,
                    PropertyTypeID: result[0].propertyTypeID,
                    PropertyTypeList: result
                });
            },
            (error) => {
            }
        )
    }
    handle = (e) => {
        e.preventDefault();
        //console.log(e.target.children[0].name);
        this.setState({...this.state, [e.target.name]: e.target.value},
            () => {
                if(e.target.name == "CityID")
                    this.getAreas();
                else if(e.target.name == "AreaID")
                    this.getBlocks();
                else if(e.target.name == "BlockID")
                    this.getBuilders();
                else if(e.target.name == "CNIC")
                    this.isCNICExist();
            }
        );
        
    }

    isCNICExist = () => {
        if(this.state.CNIC == ""){
            this.setState({...this.state, ValidCNIC: true});
            document.getElementById("CNICNotExistError").style.display = 'none';
            document.getElementById("CNICError").style.display = 'none';
        }
        else{
            fetch("https://localhost:44385/property/IsCNICExist?CNIC=" + this.state.CNIC.replace("-", "").replace("-", ""))
            .then(res => res.json())
            .then(
                async (result) => {
                    if(result){
                        this.setState({...this.state, ValidCNIC: true});
                        document.getElementById("CNICNotExistError").style.display = 'none';
                    }
                    else if(!result && /[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.CNIC)){
                        this.setState({...this.state, ValidCNIC: false});
                        document.getElementById("CNICNotExistError").style.display = 'block';
                        document.getElementById("CNICError").style.display = 'none';
                    }
                    else if(!result && !/[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.CNIC)){
                        document.getElementById("CNICNotExistError").style.display = 'none';
                    }
                },
                (error) => {
                }
            )
        }
    }
    submit = (e) => {
        e.preventDefault();
        let count = 0;
        document.getElementById("PropertyNumberError").style.display = 'none';
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == '' && answer.id != "CNIC"){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            } 
        })
        document.querySelectorAll('form select').forEach(answer => {     
            if(answer.value == '-1'){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }     
        })
        document.querySelectorAll('form textarea').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            } 
        })
        if((!/[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.CNIC) || this.state.CNIC.length != 15) && this.state.CNIC != ""){
            document.getElementById("CNICError").style.display = 'block';
            count++;
        }
        else{
            document.getElementById("CNICError").style.display = 'none';
        }
        if(!this.state.ValidCNIC){
            count++;
        }
        console.log(count);
        if(count == 0){
            this.insertProperty();
        }
    }
    async insertProperty(){
        
        let p = this.BusinessModelParser.MapStateToProperty(this.state);
        console.log(p);
        fetch("https://localhost:44385/property/IsPropertyNameExistInProject?PropertyNumber=" + this.state.PropertyNumber + "&ProjectID=" + this.state.ProjectID)
        .then(res => res.json())
        .then(
            (result) => {
                if(!result){
                    fetch("https://localhost:44385/property/InsertProperty?json=" + JSON.stringify(p), {
                        method: 'POST'
                    })
                    .then(res => res.json())
                    .then(
                        (result) => {
                            this.setState({...this.state, InsertSuccess: true});
                        },
                        (error) => {
                            this.setState({...this.state, InsertSuccess: true});
                        }
                    )
                }
                else if(this.state.PropertyNumber != ""){
                    document.getElementById("PropertyNumberError").style.display = 'block';
                }
            },
            (error) => {
            }
        )
    }

    render(){
        return(
            <div className="row">
                <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1">
                <form onSubmit={this.submit}>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="PropertyNumber">Property Number</label>
                            <input id="PropertyNumber" className="form-control" name="PropertyNumber" type="text" value={this.state.PropertyNumber} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="PropertyNumberError">PropertyNumber already exist into the project</p>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="PropertyTypeID">Property Type</label>
                            <select id="PropertyTypeID" className="form-control" name="PropertyTypeID" onChange={this.handle}>
                                {
                                    this.state.PropertyTypeList != null?
                                        this.state.PropertyTypeList.map((PropertyType) =>
                                            <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="NoOfBedrooms">No. of Bedrooms</label>
                            <input id="NoOfBedrooms" className="form-control" name="NoOfBedrooms" type="number" value={this.state.NoOfBedrooms} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="NoOfBathrooms">No. of Bathrooms</label>
                            <input id="NoOfBathrooms" name="NoOfBathrooms" className="form-control" type="number" value={this.state.NoOfBathrooms} onChange={this.handle}/>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="Floor">Floor</label>
                            <input id="Floor" name="Floor" className="form-control" type="number" value={this.state.Floor} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="Area">Area in Sq. Yards</label>
                            <input id="Area" className="form-control" name="Area" type="number" value={this.state.Area} onChange={this.handle}/>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="Price">Price</label>
                            <input id="Price" className="form-control" name="Price" type="number" value={this.state.Price} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="CityID">City</label>
                            <select id="CityID" className="form-control" name="CityID" onChange={this.handle}>
                                {
                                    this.state.CityList != null?
                                        this.state.CityList.map((City) =>
                                            <option key={City.cityID} value={City.cityID}>{City.cityName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="AreaID">Area</label>
                            <select id="AreaID" className="form-control" name="AreaID" onChange={this.handle}>
                                {
                                    this.state.AreaList != null?
                                        this.state.AreaList.map((Area) =>
                                            <option key={Area.areaID} value={Area.areaID}>{Area.areaName}</option>
                                        ): <option value="" disabled selected>City is not selcted</option>
                                }
                            </select>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="BlockID">Block</label>
                            <select id="BlockID" className="form-control" name="BlockID" onChange={this.handle}>
                                {
                                    this.state.BlockList != null?
                                        this.state.BlockList.map((Block) =>
                                            <option key={Block.blockID} value={Block.blockID}>{Block.blockName}</option>
                                        ): <option value="" disabled selected>Area is not selected</option>
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="BuilderID">Builder</label>
                            <select id="BuilderID" className="form-control" name="BuilderID" onChange={this.handle}>
                                {
                                    this.state.BuilderList != null?
                                        this.state.BuilderList.map((Builder) =>
                                            <option key={Builder.builderID} value={Builder.builderID}>{Builder.builderName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="ProjectID">Project</label>
                            <select id="ProjectID" className="form-control" name="ProjectID" onChange={this.handle}>
                                {
                                    this.state.ProjectList != null?
                                        this.state.ProjectList.map((Project) =>
                                            <option key={Project.projectID} value={Project.projectID}>{Project.projectName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="CNIC">CNIC</label>
                            <input id="CNIC" className="form-control" name="CNIC" type="text" value={this.state.CNIC} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="CNICError">Please match the format xxxxx-xxxxxxx-x</p>
                            <p style={{color: "red", display: "none"}} id="CNICNotExistError">There is no user against the CNIC</p>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-12">    
                            <label htmlFor="Description">Description</label>
                            <textarea id="Description" name="Description" className="form-control" value={this.state.Description} onChange={this.handle}/>
                        </div>
                    </div>
                    <div className="form-row">    
                    <input  className="btn btn-primary" type="submit" value="submit"/>
                    </div>
                </form>
                {
                    this.state.InsertSuccess == true? <AddPropertyNavigate></AddPropertyNavigate>: <></>
                }
                        {/* <input name="PropertyNumber" type="text" value={this.state.PropertyNumber} onChange={this.handle}/>
                        <input name="NoOfBathrooms" type="number" value={this.state.NoOfBathrooms} onChange={this.handle}/>
                        <input name="NoOfBedrooms" type="number" value={this.state.NoOfBedrooms} onChange={this.handle}/>
                        <input name="Area" type="number" value={this.state.Area} onChange={this.handle}/>
                        <select name="PropertyTypeID" onChange={this.handle}>
                            {
                                this.state.PropertyTypeList != null?
                                    this.state.PropertyTypeList.map((PropertyType) =>
                                        <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                    ): "Loading"
                            }
                        </select> */}
                        {/* <input name="Floor" type="number" value={this.state.Floor} onChange={this.handle}/>
                        <input name="Description" type="text" value={this.state.Description} onChange={this.handle}/>
                        <input name="ProjectID" type="text" value={this.state.ProjectID} onChange={this.handle}/>
                        <input name="Price" type="number" value={this.state.Price} onChange={this.handle}/> */}
                        
                </div>
            </div>
        )
    }
}

function AddPropertyNavigate(){
    let navigate = useNavigate();
    useEffect(()=>{
        navigate("/viewprojects");
    }, []);
}

export default AddProperty;
