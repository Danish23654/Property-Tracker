import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import './PropertyDashboard.css'

class PropertyDashboard extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { properties: [] };
    }
    componentDidMount(){
        fetch("https://localhost:44385/property/getallproperties")
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    properties: result
                });
            },
            (error) => {
            }
        )
    }

  render(){
    return(
      <>
        <form onSubmit={this.submit}>
                    <div className="form-row">
                        <div className="form-group col-md-2">
                            <label htmlFor="PropertyNumber">Property Number</label>
                            <input id="PropertyNumber" className="form-control" name="PropertyNumber" type="text" value={this.state.PropertyNumber} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-2">
                            <label htmlFor="PropertyTypeID">Property Type</label>
                            <select id="PropertyTypeID" className="form-control" name="PropertyTypeID" onChange={this.handle}>
                                {
                                    this.state.PropertyTypeList != null?
                                        this.state.PropertyTypeList.map((PropertyType) =>
                                            <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="Price">Price</label>
                            <input id="Price" className="form-control" name="Price" type="number" value={this.state.Price} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="CityID">City</label>
                            <select id="CityID" className="form-control" name="CityID" onChange={this.handle}>
                                {
                                    this.state.CityList != null?
                                        this.state.CityList.map((City) =>
                                            <option key={City.cityID} value={City.cityID}>{City.cityName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="AreaID">Area</label>
                            <select id="AreaID" className="form-control" name="AreaID" onChange={this.handle}>
                                {
                                    this.state.AreaList != null?
                                        this.state.AreaList.map((Area) =>
                                            <option key={Area.areaID} value={Area.areaID}>{Area.areaName}</option>
                                        ): <option value="" disabled selected>City is not selcted</option>
                                }
                            </select>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="BlockID">Block</label>
                            <select id="BlockID" className="form-control" name="BlockID" onChange={this.handle}>
                                {
                                    this.state.BlockList != null?
                                        this.state.BlockList.map((Block) =>
                                            <option key={Block.blockID} value={Block.blockID}>{Block.blockName}</option>
                                        ): <option value="" disabled selected>Area is not selected</option>
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="BuilderID">Builder</label>
                            <select id="BuilderID" className="form-control" name="BuilderID" onChange={this.handle}>
                                {
                                    this.state.BuilderList != null?
                                        this.state.BuilderList.map((Builder) =>
                                            <option key={Builder.builderID} value={Builder.builderID}>{Builder.builderName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="ProjectID">Project</label>
                            <select id="ProjectID" className="form-control" name="ProjectID" onChange={this.handle}>
                                {
                                    this.state.ProjectList != null?
                                        this.state.ProjectList.map((Project) =>
                                            <option key={Project.projectID} value={Project.projectID}>{Project.projectName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                    </div>
                    <div className="form-row">    
                        <label htmlFor="Description">Description</label>
                        <textarea id="Description" name="Description" className="form-control" value={this.state.Description} onChange={this.handle}/>
                    </div>
                    <div className="form-row">    
                    <input  className="btn btn-primary" type="submit" value="submit"/>
                    </div>
                </form>
        <span class="glyphicon glyphicon-search"></span>
        {this.state.properties.map((property) =>
            <div className='row'>
                <div className='custom-card col-lg-8 offset-2 col-md-8 col-sm-8 col-xs-8'>
                    <Link to={"/propertydetails/" + property.propertyID} style={{textDecoration: "none"}}>
                        <div className='row'>
                            <div className='col-lg-3  col-md-3 col-sm-4 col-xs-4'>
                            </div>
                            <div className='col-lg-9  col-md-9 col-sm-8 col-xs-8'>
                                PKR <span style={ {fontWeight: "bold", fontSize: "25px"}}>{property.price}</span>
                                <br></br>
                                {property.project.block.blockName}, {property.project.block.area.areaName}, {property.project.block.area.city.cityName}
                                <br></br>
                                <span class="glyphicon glyphicon-bed"></span> {property.noOfBedrooms}&nbsp;&nbsp;
                                <span class="glyphicon glyphicon-tint"></span> {property.noOfBathrooms}&nbsp;&nbsp;
                                <span class="glyphicon glyphicon-scale"></span> {property.area} Sq. Yards&nbsp;
                                <br></br>
                                {property.description}
                                <br></br><br></br>
                                {property.project.projectName} by <b>{property.project.builder.builderName}</b>
                            </div>
                        </div>
                    </Link>
                </div>
            </div>
        )}
      </>
    );
  };
}
export default PropertyDashboard;
