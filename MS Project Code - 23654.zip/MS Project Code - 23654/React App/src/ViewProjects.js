import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';

class ViewProjects extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { projects: [] };
        console.log(this.props.userID);
        this.userID = this.props.userID;
    }
    componentDidMount(){
        fetch("https://localhost:44385/property/getallprojects?UserID=" + this.userID)
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    projects: result
                }, () => {
                    console.log(this.state.projects);
                });
            },
            (error) => {
            }
        )
    }

  render(){
    return(
      <>
        <div className='col-md-10 offset-md-1'>
            <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}>
                {
                    this.props.userID != null? 
                        <strong>My Projects</strong>
                        :<strong>Projects</strong>
                }
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Project</th>
                        <th scope="col">Builder</th>
                        <th scope="col">Block</th>
                        <th scope="col">Area</th>
                        <th scope="col">City</th>
                        {
                            this.userID != undefined? 
                                <th></th>:
                                <></>
                        }
                    </tr>
                </thead>
                <tbody>
                    {
                        
                        this.state.projects.map((project, index) => 
                            <tr>
                                <th scope="row">{index + 1}</th>
                                <td>{project.projectName}</td>
                                <td><Link to={"/builderdetails/" + project.builder.builderID}>{project.builder.builderName}</Link></td>
                                <td>{project.block.blockName}</td>
                                <td>{project.block.area.areaName}</td>
                                <td>{project.block.area.city.cityName}</td>
                                {
                                    this.userID != undefined? 
                                        <td>
                                            <Link to={"/editproject/" + project.projectID}>
                                                <button type="button" class="btn btn-primary">
                                                    Edit
                                                </button>
                                            </Link>
                                        </td>:
                                        <></>
                                }
                            </tr>
                        )
                    }
                </tbody>
            </table>
            {
                (this.state.projects.length == 0 || this.state.projects == null) && this.props.userID == undefined? 
                <div class="alert alert-primary" role="alert">
                    There are no Projects into the system.
                </div>: 
                this.state.projects.length == 0 || this.state.projects == null? 
                <div class="alert alert-primary" role="alert">
                    You do not have Project(s)
                </div>: <></>
            }
            {/* {
                this.state.builders.map((builder) =>
                    <div className="card" key={builder.builderID}>
                        <h5 className="card-header">{builder.builderName}</h5>
                        <div className="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Project Name</th>
                                        <th scope="col">Block</th>
                                        <th scope="col">Area</th>
                                        <th scope="col">City</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        
                                        builder.projects.map((project) => 
                                            <tr>
                                                <th scope="row">1</th>
                                                <td>{project.projectName}</td>
                                                <td>{project.block.blockName}</td>
                                                <td>{project.block.area.areaName}</td>
                                                <td>{project.block.area.city.cityName}</td>
                                            </tr>
                                        )
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                )
            } */}
        </div>
      </>
    );
  };
}
export default ViewProjects;
