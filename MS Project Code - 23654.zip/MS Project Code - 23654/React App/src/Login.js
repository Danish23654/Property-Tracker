import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect, createRef} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser, User} from './BusinessModelParser.ts';

function Login(){
    const PasswordRef = createRef();
    const EmailAddressRef = createRef();
    const navigate = useNavigate();
    const [user, setUser] = useState(
                { 
                    emailAddress: "",
                    password: ""
                }
            );
    useEffect(() => {
        //navigate("/propertydashboard");
    });
    
    function handle(e){
        e.preventDefault();
        setUser({...user, [e.target.name]: e.target.value});
    }
    function submit(e){
        e.preventDefault();
        validate(user.emailAddress, user.password);
    }
    async function validate(EmailAddress, Password){
        let obj = new BusinessModelParser();
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }
        })
        if(EmailAddress != "" && Password != "" && !await obj.IsValidLogin(EmailAddress, Password)){
            document.getElementById("LoginError").style.display = "block";
            EmailAddressRef.current.style.borderColor = 'red';
            PasswordRef.current.style.borderColor = 'red';
            count++;
        }
        if(count == 0){
            Login();
        }
    }
    
    async function Login(){
        console.log("correct");
        await localStorage.setItem('UserID', await new BusinessModelParser().GetUserIDByEmailAddress(user.emailAddress));
        window.location.href = "/propertydashboard";// navigate("/propertydashboard");
    }
    return(
        <div className="row">
            
            <div className="col-lg-4 col-md-10 col-sm-10 col-xs-10 offset-lg-4 offset-md-1 offset-sm-1 offset-xs-1">
                <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Sign In</strong></div>
                <form onSubmit={submit} className="jumbotron">
                    <div className="form-row">
                        <div className="form-group col-md-10 offset-md-1">
                            <label htmlFor="emailAddress">Email Address</label>
                            <input id="emailAddress" ref={EmailAddressRef} className="form-control" name="emailAddress" type="text" value={user.emailAddress} onChange={handle}/>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-10 offset-md-1">
                            <label htmlFor="password">Password</label>
                            <input id="password" ref={PasswordRef} className="form-control" name="password" type="password" value={user.password} onChange={handle}/>
                        </div>
                        <div className="form-group col-md-10 offset-md-1">
                        <p style={{color: "red", display: "none", textAlign: "center"}} id="LoginError">Email Address or Password is incorrect</p>
                        </div>
                    
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-10 offset-md-1">    
                            <span class="glyphicon glyphicon-user"></span>
                            <input  className="btn btn-primary btn-block" type="submit" value="Sign In"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}

// class Login extends React.Component{
//     CNICRef = createRef();
//     PasswordRef = createRef();
//     ConfirmPasswordRef = createRef();
//     EmailAddressRef = createRef();
//     constructor(props){
//         super(props);
//         this.BusinessModelParser = new BusinessModelParser();
//         this.state = { 
//             userID: 1,
//             emailAddress: "",
//             password: ""
//         };
//         browserHistory.push('/propertydashboard');
//     }
//     async componentDidMount(){
//     }
//     handle = (e) => {
//         e.preventDefault();
//         this.setState({...this.state, [e.target.name]: e.target.value});
        
//     }
//     submit = (e) => {
//         e.preventDefault();
//         this.validate(this.state.emailAddress, this.state.password);
//     }
//     async validate(EmailAddress, Password){
//         let count = 0;
//         document.querySelectorAll('form input').forEach(answer => {     
//             if(answer.value == ''){
//                 answer.style.borderColor = 'red';
//                 count++;
//             }
//             else{
//                 answer.style.borderColor = '';
//             }
//         })
//         if(EmailAddress != "" && Password != "" && !await this.BusinessModelParser.IsValidLogin(EmailAddress, Password)){
//             document.getElementById("LoginError").style.display = "block";
//             this.EmailAddressRef.current.style.borderColor = 'red';
//             this.PasswordRef.current.style.borderColor = 'red';
//             count++;
//         }
//         if(count == 0){
//             this.Login();
//         }
//     }
//     Login = () => {
//         console.log("correct");
//         this.props.history.push("propertydashboard");
//     }

//     render(){
//         return(
//             <div className="row">
//                 <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1">
//                     <form onSubmit={this.submit}>
//                         <div className="form-row">
//                             <div className="form-group col-md-6">
//                                 <label htmlFor="emailAddress">Email Address</label>
//                                 <input id="emailAddress" ref={this.EmailAddressRef} className="form-control" name="emailAddress" type="text" value={this.state.emailAddress} onChange={this.handle}/>
//                             </div>
//                             <div className="form-group col-md-6">
//                                 <label htmlFor="password">Password</label>
//                                 <input id="password" ref={this.PasswordRef} className="form-control" name="password" type="text" value={this.state.password} onChange={this.handle}/>
//                             </div>
//                         </div>
//                         <p style={{color: "red", display: "none"}} id="LoginError">Email Address or Password is incorrect</p>
//                         <div className="form-row">    
//                             <input  className="btn btn-primary" type="submit" value="Login"/>
//                         </div>
//                     </form>
//                 </div>
//             </div>
//         )
//     }
// }

export default Login;
