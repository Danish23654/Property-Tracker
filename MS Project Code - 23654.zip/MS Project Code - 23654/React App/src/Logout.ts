import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Routes, Router, NavLink, useParams, useNavigate, Navigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser';

function Logout(){
    let navigate = useNavigate();
    useEffect(() => {
        let UserID = localStorage.getItem("UserID");
        localStorage.setItem("UserID", "");
        if(UserID != "" && UserID != null) {
            window.location.reload();
        }
        else{
            navigate("/propertyDashboard");
        }
    })
}

export default Logout;