import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';

function BuilderDetails(){
    let [builder, setBuilder] = useState({});
    let {builderID} = useParams();
    useEffect(()=>{
        console.log(builderID);
        fetch("https://localhost:44385/property/GetBuilderByBuilderID?BuilderID=" + builderID)
        .then(res => res.json())
        .then(
            (result) => {
                console.log(result);
                setBuilder(result);
            },
            (error) => {
            }
        )
    },[])
    return(
        
        <div className="row">
            <div className="col-md-8 offset-md-2">
            {
                builder.builderName != null?
                    <div className="card" key={builder.builderID}>
                        <h5 className="card-header" style={{backgroundColor: "#343a40", color: "white"}}>{builder.builderName} <span style={{float: "right"}}>{builder.mobileNumber.substring(0, 4)}-{builder.mobileNumber.substring(4, 11)}</span></h5>
                        <div className="card-body">
                            <div style={{marginBottom: "20px"}}>
                                {builder.description}
                            </div>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Project Name</th>
                                        <th scope="col">Block</th>
                                        <th scope="col">Area</th>
                                        <th scope="col">City</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        
                                        builder.projects.map((project, index) => 
                                            <tr>
                                                <th scope="row">{index + 1}</th>
                                                <td>{project.projectName}</td>
                                                <td>{project.block.blockName}</td>
                                                <td>{project.block.area.areaName}</td>
                                                <td>{project.block.area.city.cityName}</td>
                                            </tr>
                                        )
                                    }
                                </tbody>
                            </table>
                            
                            {
                                builder.projects.length == 0? 
                                <div class="alert alert-primary" role="alert">
                                    There is no Project under {builder.builderName}
                                </div>: <></>
                            }
                        </div>
                    </div> : <></>
            }
            
            </div>
        </div>
    );
}

export default BuilderDetails;
