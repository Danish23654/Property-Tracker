import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import ViewBuilders from './ViewBuilders';

class MyBuilders extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { builders: [] };
    }

  render(){
    return(
      <>
        <ViewBuilders userID={localStorage.getItem("UserID")}></ViewBuilders>
      </>
    );
  };
}
export default MyBuilders;
