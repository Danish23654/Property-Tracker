import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect, createRef} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import {Builder, Property, BusinessModelParser, User} from './BusinessModelParser.ts';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class EditUser extends React.Component{
    CNICRef = createRef();
    PasswordRef = createRef();
    ConfirmPasswordRef = createRef();
    EmailAddressRef = createRef();
    MobileNumberRef = createRef();
    constructor(){
        super();
        this.BusinessModelParser = new BusinessModelParser();
        this.state = { 
            userID: localStorage.getItem("UserID"),
            firstName: "",
            lastName: "",
            cnic: "",
            emailAddress: "",
            password: "",
            confirmPassword: "",
            mobileNumber: ""
        };
    }
    async componentDidMount(){
        let user = await this.BusinessModelParser.GetUserByUserID(this.state.userID);
        user.cnic = user.cnic != null? user.cnic.substring(0, 5) + "-" + user.cnic.substring(5, 12) + "-" + user.cnic.substring(12, 13): "";
        user.mobileNumber = user.mobileNumber != null? user.mobileNumber.substring(0, 4) + "-" + user.mobileNumber.substring(4, 12): "";
        await this.setState(user);
        console.log(this.state);
    }
    handle = (e) => {
        e.preventDefault();
        //console.log(e.target.children[0].name);
        this.setState({...this.state, [e.target.name]: e.target.value},
            () => {
                if(e.target.name == "CityID")
                    this.getAreas();
                else if(e.target.name == "AreaID")
                    this.getBlocks();
                else if(e.target.name == "BlockID")
                    this.getBuilders();
            }
        );
        
    }
    submit = (e) => {
        e.preventDefault();
        this.validate(this.state.userID, this.state.cnic, this.state.password, this.state.confirmPassword, this.state.emailAddress, this.state.mobileNumber);
    }
    async validate(UserID, CNIC, Password, ConfirmPassword, EmailAddress, MobileNumber){
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }
        })
        if(Password != ConfirmPassword){
            this.PasswordRef.current.style.borderColor = 'red';
            this.ConfirmPasswordRef.current.style.borderColor = 'red';
            document.getElementById("PasswordError").style.display = "block";
            count++;
        }
        else if(Password != ""){
            document.getElementById("PasswordError").style.display = "none";
            this.PasswordRef.current.style.borderColor = '';
            this.ConfirmPasswordRef.current.style.borderColor = '';
        }
        if(!/[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.cnic) || (this.state.cnic != "" && this.state.cnic.length != 15)){
            document.getElementById("CNICError").style.display = 'block';
            document.getElementById("CNICExistError").style.display = 'none';
            count++;
        }
        else{
            document.getElementById("CNICError").style.display = 'none';
            if(CNIC != "" && true == await this.BusinessModelParser.IsCNICExist(CNIC, this.state.userID)){
                count++;
                document.getElementById("CNICExistError").style.display = 'block';
                this.CNICRef.current.style.borderColor = 'red';
            }
            else if(CNIC != ""){
                this.CNICRef.current.style.borderColor = '';
                document.getElementById("CNICExistError").style.display = 'none';
            }
        }
        if(!/[0-9]{4}-[0-9]{7}/.test(this.state.mobileNumber) || (this.state.mobileNumber != "" && this.state.mobileNumber.length != 12)){
            document.getElementById("MobileNumberError").style.display = 'block';
            count++;
        }
        else{
            document.getElementById("MobileNumberError").style.display = 'none';
            if(MobileNumber != ""){
                this.MobileNumberRef.current.style.borderColor = '';
            }
        }
        let IsEmailExist = false;
        await fetch("https://localhost:44385/property/IsEmailExist?EmailAddress=" + EmailAddress + "&UserID=" + UserID)
        .then(res => res.json())
        .then(
            async (result) => {
                //console.log(result);
                IsEmailExist = await result;
            },
            (error) => {
            }
        )
        if(EmailAddress != "" && true == IsEmailExist){
            document.getElementById("EmailAddressError").style.display = "block";
            this.EmailAddressRef.current.style.borderColor = 'red';
            count++;
        }
        else if(EmailAddress != ""){
            document.getElementById("EmailAddressError").style.display = "none";
            this.EmailAddressRef.current.style.borderColor = '';
        }
        if(count == 0){
            this.UpdateAccount();
        }
    }
    UpdateAccount = () => {
        
        //let u = this.BusinessModelParser.MapStateToUser(this.state);
        let user = new User();
        user.firstName = this.state.firstName;
        user.lastName = this.state.lastName;
        user.emailAddress = this.state.emailAddress;
        user.cnic = this.state.cnic;
        user.password = this.state.password;
        user.mobileNumber = this.state.mobileNumber;
        user.userID = this.state.userID;
        fetch("https://localhost:44385/property/UpdateAccount?json=" + JSON.stringify(user), {
            method: 'POST'
        })
        .then(res => res.json())
        .then(
            (result) => {
            },
            (error) => {
                toast("User's information has been Updated")
            }
        )
    }

    render(){
        return(
            <div className="row">
                <ToastContainer />
                <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1" style={{marginBottom: "40px"}}>
                <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Edit User</strong></div>
                <form onSubmit={this.submit} className="jumbotron" style={{paddingLeft: "60px", paddingRight: "60px"}}>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="firstName">First Name</label>
                            <input id="firstName" className="form-control" name="firstName" type="text" value={this.state.firstName} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="lastName">Last Name</label>
                            <input id="lastName" className="form-control" name="lastName" type="text" value={this.state.lastName} onChange={this.handle}/>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="emailAddress">Email Address</label>
                            <input id="emailAddress" ref={this.EmailAddressRef} className="form-control" name="emailAddress" type="text" value={this.state.emailAddress} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="EmailAddressError">Email address already exist</p>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="cnic">CNIC</label>
                            <input id="cnic" ref={this.CNICRef} className="form-control" name="cnic" type="text" value={this.state.cnic} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="CNICExistError">CNIC already exist</p>
                            <p style={{color: "red", display: "none"}} id="CNICError">Please match the format xxxxx-xxxxxxx-x</p>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="password">Password</label>
                            <input id="password" ref={this.PasswordRef} className="form-control" name="password" type="password" value={this.state.password} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="confirmPassword">Confirm Password</label>
                            <input id="confirmPassword" ref={this.ConfirmPasswordRef} className="form-control" name="confirmPassword" type="password" value={this.state.confirmPassword} onChange={this.handle}/>
                        </div>
                        <p style={{color: "red", display: "none"}} id="PasswordError">Password and Confirm Password do not match</p>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="mobileNumber">Mobile Number</label>
                            <input id="mobileNumber" ref={this.MobileNumberRef} className="form-control" name="mobileNumber" type="text" value={this.state.mobileNumber} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="MobileNumberError">Please match the format xxxx-xxxxxxx</p>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="asd" style={{ color: "white" }}>sda</label>  
                            <input  className="btn btn-primary col-md-12" type="submit" value="Edit User"/>
                        </div>
                    </div>
                </form>

                        {/* <input name="PropertyNumber" type="text" value={this.state.PropertyNumber} onChange={this.handle}/>
                        <input name="NoOfBathrooms" type="number" value={this.state.NoOfBathrooms} onChange={this.handle}/>
                        <input name="NoOfBedrooms" type="number" value={this.state.NoOfBedrooms} onChange={this.handle}/>
                        <input name="Area" type="number" value={this.state.Area} onChange={this.handle}/>
                        <select name="PropertyTypeID" onChange={this.handle}>
                            {
                                this.state.PropertyTypeList != null?
                                    this.state.PropertyTypeList.map((PropertyType) =>
                                        <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                    ): "Loading"
                            }
                        </select> */}
                        {/* <input name="Floor" type="number" value={this.state.Floor} onChange={this.handle}/>
                        <input name="Description" type="text" value={this.state.Description} onChange={this.handle}/>
                        <input name="ProjectID" type="text" value={this.state.ProjectID} onChange={this.handle}/>
                        <input name="Price" type="number" value={this.state.Price} onChange={this.handle}/> */}
                        
                </div>
            </div>
        )
    }
}

export default EditUser;
