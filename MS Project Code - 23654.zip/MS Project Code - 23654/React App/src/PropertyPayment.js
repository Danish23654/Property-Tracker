import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';


class PropertyPayment extends React.Component{
    constructor(props){
        super(props);
        this.BusinessModelParser = new BusinessModelParser();
    }
    async componentDidMount(){
    }
    

    render(){
        return(
            <>
            <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Payment Plan</strong></div>
            
                <p style={{color: "red"}}>Note: Payment Information will be associated with the Owner, if you remove the Owner's CNIC then Payment Information will not be saved.</p>
                <form onSubmit={this.submit}>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="paymentPlanTypeID">Payment Plan Type</label>
                            <select id="paymentPlanTypeID" className="form-control" name="paymentPlanTypeID" onChange={this.props.handle}>
                                {
                                    this.props.parentState.paymentPlanTypes != null && this.props.parentState.paymentPlanTypes != []?
                                        this.props.parentState.paymentPlanTypes.map((paymentPlanType) =>
                                            <option key={paymentPlanType.paymentPlanTypeID} value={paymentPlanType.paymentPlanTypeID}>{paymentPlanType.paymentPlanTypeName}</option>
                                        ): "Loading"
                                }
                            </select>
                        </div>
                        {
                            this.props.parentState.loanAmount != "" && this.props.parentState.totalInstallments != ""?
                                <div className="form-group col-md-6">
                                    <label htmlFor="paidInstallments" style={{color: "white"}}>Paid Installments</label>
                                    <p><strong>Amount per Installment:</strong> {this.props.parentState.loanAmount / this.props.parentState.totalInstallments}</p>
                                </div>:
                                <></>
                        }
                    </div>
                    {
                        this.props.parentState.paymentPlanTypes != null && this.props.parentState.paymentPlanTypes != [] && this.props.parentState.paymentPlanTypeID == this.props.parentState.paymentPlanTypes.filter(x=>x.paymentPlanTypeName == "Installments")[0].paymentPlanTypeID?
                        <>
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <label htmlFor="downPayment">Down Payment</label>
                                    <input id="downPayment" name="downPayment" className="form-control" type="number" value={this.props.parentState.downPayment} onChange={this.props.handle}/>
                                </div>
                                <div className="form-group col-md-6">
                                    <label htmlFor="loanAmount">Loan Amount</label>
                                    <input id="loanAmount" name="loanAmount" className="form-control" type="number" value={this.props.parentState.loanAmount} onChange={this.props.handle}/>
                                </div>
                            </div>
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <label htmlFor="totalInstallments">Total Installments</label>
                                    <input id="totalInstallments" className="form-control" name="totalInstallments" type="number" value={this.props.parentState.totalInstallments} onChange={this.props.handle}/>
                                </div>
                                <div className="form-group col-md-6">
                                    <label htmlFor="paidInstallments">Paid Installments</label>
                                    <input id="paidInstallments" name="paidInstallments" className="form-control" type="number" value={this.props.parentState.paidInstallments} max={this.props.parentState.totalInstallments} onChange={this.props.handle}/>
                                    <p style={{color: "red", display: "none"}} id="paidInstallmentsError">Paid Installments cannot be greater than Total Installments</p>
                                </div>
                            </div>
                        </>
                        : <></>
                    }
                </form>
                {
                    this.props.parentState.InsertSuccess == true? <AddPropertyNavigate></AddPropertyNavigate>: <></>
                }
                </>
        )
    }
}

function AddPropertyNavigate(){
    let navigate = useNavigate();
    useEffect(()=>{
        navigate("/createdProperties");
    }, []);
}

export default PropertyPayment;
