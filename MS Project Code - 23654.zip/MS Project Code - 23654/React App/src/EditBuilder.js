import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


function EditBuilder(){
    
    //navigate = useNavigate();
    let navigate = useNavigate();
    let {builderID} = useParams();
    let [state, setState] = useState(
        {
            builderID: 0,
            builderName: "",
            builderList: null,
            userID: localStorage.getItem("UserID"),
            description: "",
            mobileNumber: ""
        }
    );

    useEffect(()=>{
        fetch("https://localhost:44385/property/GetBuilderByBuilderID?BuilderID=" + builderID)
        .then(res => res.json())
        .then(
            async (result) => {
                console.log(result);
                setState({...state, builderID: result.builderID, builderName: result.builderName, description: result.description, mobileNumber: result.mobileNumber != null && result.mobileNumber != ""? result.mobileNumber.substring(0, 4) + "-" + result.mobileNumber.substring(4, 11): ""});
                console.log(state);
            },
            (error) => {
            }
        )
    }, []);
    
    function handle(e){
        e.preventDefault();
        //console.log(e.target.children[0].name);
        setState({...state, [e.target.name]: e.target.value});
        
    }

    function submit(e){
        e.preventDefault();
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }  
        })
        document.querySelectorAll('form textarea').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }  
        })
        
        if(!/[0-9]{4}-[0-9]{7}/.test(state.mobileNumber) || (state.mobileNumber != "" && state.mobileNumber.length != 12)){
            document.getElementById("MobileNumberError").style.display = 'block';
            count++;
        }
        else{
            document.getElementById("MobileNumberError").style.display = 'none';
        }

        if(count == 0){
            //
            updateBuilder();
        }
        
    }
    async function updateBuilder(){
        
        await fetch("https://localhost:44385/property/GetAllBuilders?BuilderID=" + builderID)
        .then(res => res.json())
        .then(
            async (result) => {
                let count = 0;
                await result.forEach((Builder) => {
                    if(Builder.builderName == state.builderName){
                        count = 1;
                        document.getElementById("BuilderNameError").style.display = 'block';
                    }
                })
                
                if(count == 0){
                    document.getElementById("BuilderNameError").style.display = 'none';
                    let b = await new BusinessModelParser().MapStateToBuilder(state);
                    fetch("https://localhost:44385/property/UpdateBuilder?json=" + JSON.stringify(b), {
                        method: 'POST'
                    })
                    .then(res => res.json())
                    .then(
                        (result) => {
                        },
                        (error) => {
                            toast("Builder's Information has been Updated");
                        }
                    )
                }
            },
            (error) => {
            }
        )
    }

    return(
        <div className="row">
            <ToastContainer />
            <div className="col-lg-6 col-md-10 col-sm-10 col-xs-10 offset-lg-3 offset-md-1 offset-sm-1 offset-xs-1" style={{marginBottom: "40px"}}>
            <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Edit Builder</strong></div>
            <form onSubmit={submit} className="jumbotron" style={{paddingLeft: "60px", paddingRight: "60px"}}>
                <div className="form-row">
                    <div className="form-group col-md-6">
                        <label htmlFor="builderName">Builder Name</label>
                        <input id="builderName" className="form-control" name="builderName" type="text" value={state.builderName} onChange={handle}/>
                        <p style={{color: "red", display: "none"}} id="BuilderNameError">A Builder already exist with this name</p>
                    </div>
                    <div className="form-group col-md-6">
                        <label htmlFor="mobileNumber">Phone Number</label>
                        <input id="mobileNumber" className="form-control" name="mobileNumber" type="text" value={state.mobileNumber} onChange={handle}/>
                        <p style={{color: "red", display: "none"}} id="MobileNumberError">Please match the format xxxx-xxxxxxx</p>
                    </div>
                </div>
                <div className="form-row">    
                    <div className="form-group col-md-12">
                        <label htmlFor="description">Description</label>
                        <textarea id="description" name="description" className="form-control" value={state.description} onChange={handle}/>
                    </div>
                </div>
                <div className="form-row">   
                    <div className="form-group col-md-4">
                    </div> 
                    <div className="form-group col-md-4">
                    </div>
                    <div className="form-group col-md-4">
                        <input  className="btn btn-primary col-md-12" type="submit" value="Edit Builder"/>
                    </div>
                </div>
            </form>
            </div>
        </div>
    )
}

export default EditBuilder;
