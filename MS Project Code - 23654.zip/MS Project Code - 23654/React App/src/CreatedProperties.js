import logo from './logo.svg';
import './App.css';
import React, {useState, useContext} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams } from 'react-router-dom';
import './PropertyDashboard.css'
import PropertyDashboard from './PropertyDashboard.js';

class CreatedProperties extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { properties: [] };
    }
    componentDidMount(){
        
    }

  render(){
    return(
      <>
        <div class="row">
          <div className="col-md-10 offset-md-1">
            <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}>
              <strong>Created Properties</strong>
            </div>
          </div>
        </div>
        <PropertyDashboard CreatedProperties={true}/>
      </>
    );
  };
}
export default CreatedProperties;
