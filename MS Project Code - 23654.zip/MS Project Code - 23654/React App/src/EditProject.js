import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function EditProject() {
    let navigate = useNavigate();
    let {projectID} = useParams();
    return(
        <>
            <EditProject1 projectID={projectID}/>
        </>
    );
}

class EditProject1 extends React.Component{ 

    constructor(props) {
        super(props);
        this.state = {
            ProjectName: "",
            Description: "",
            BuilderID: "",
            BuilderList: null,
            BlockID: "",
            BlockList: null,
            AreaID: "",
            AreaList: null,
            CityID: "",
            CityList: null,
            UserID: localStorage.getItem("UserID"),
            CityListUpdated: false,
            ProjectID: 0,
            normal: false,
            EditSuccess: false
        };
    }

    async componentDidMount(){
        await fetch("https://localhost:44385/property/getallcities")
            .then(res => res.json())
            .then(
                async (result) => {
                    await this.setState({
                        ...this.state,
                        CityList: result
                    });
                },
                (error) => {
                }
            );
        await fetch("https://localhost:44385/property/GetProjectByProjectID?ProjectID="+ this.props.projectID)
        .then(res => res.json())
        .then(
            async (result) => {
                await this.setState({ 
                    ...this.state, 
                    ProjectID: result.projectID,
                    ProjectName: result.projectName,
                    Description: result.description,
                    CityID: result.block.area.city.cityID,
                    AreaID: result.block.area.areaID,
                    BlockID: result.block.blockID,
                    BuilderID: result.builder.builderID,
                    MobileNumber: result.mobileNumber != null && result.mobileNumber != ""? result.mobileNumber.substring(0, 4) + "-" + result.mobileNumber.substring(4, 11): ""

                }, () => {
                    document.querySelectorAll('#CityID option').forEach(async (answer) => {     
                        if(answer.value == this.state.CityID){
                            answer.selected = 'selected';
                            await fetch("https://localhost:44385/property/getAllAreasByCityID?CityID=" + this.state.CityID)
                            .then(res => res.json())
                            .then(
                                async (result) => {
                                    let PlaceholderResult = [{areaID: -1, areaName: 'Not Available', city: null}];
                                    await this.setState({
                                        ...this.state,
                                        AreaList: result.length > 0? result: PlaceholderResult
                                    }, () => {
                                        document.querySelectorAll('#AreaID option').forEach(async (answer) => {    
                                            
                                            if(answer.value == this.state.AreaID){
                                                answer.selected = 'selected';
                                                
                                                await fetch("https://localhost:44385/property/getAllBlocksByAreaID?AreaID=" + this.state.AreaID)
                                                .then(res => res.json())
                                                .then(
                                                    async (result) => {
                                                        let PlaceholderResult = [{blockID: -1, blockName: 'Not Available', area: null}];
                                                        await this.setState({
                                                            ...this.state,
                                                            BlockList: result.length > 0? result: PlaceholderResult
                                                        }, () => {
                                                            document.querySelectorAll('#BlockID option').forEach(answer => {     
                                                                if(answer.value == this.state.BlockID){
                                                                    answer.selected = 'selected';
                                                                }    
                                                            })
                                                        });
                                                        
                                                    },
                                                    (error) => {
                                                    }
                                                )
                                            }    
                                        })
                                    });
                                    
                                },
                                (error) => {
                                }
                            )
                        }    
                    })
                })
            },
            (error) => {
            }
        );
        fetch("https://localhost:44385/property/GetAllBuilderNamesByUserID?UserID=" + this.state.UserID)
            .then(res => res.json())
            .then(
                async (result) => {
                    let PlaceholderResult = [{builderID: -1, builderName: 'Not Available'}];
                    await this.setState({
                        ...this.state,
                        BuilderList: result.length > 0? result: PlaceholderResult,
                        BuilderUpdate: true
                    });
                    
                    document.querySelectorAll('#BuilderID option').forEach(answer => {     
                        if(answer.value == this.state.TempBuilderID){
                            answer.selected = 'selected';
                            this.setState({...this.state, BuilderID: this.state.TempBuilderID, BuilderUpdate: false });
                        }    
                    })
                },
                (error) => {
                }
            )
    }


    getAreas = () => {
        fetch("https://localhost:44385/property/getAllAreasByCityID?CityID=" + this.state.CityID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{areaID: -1, areaName: 'Not Available', city: null}];
                this.setState({
                    ...this.state,
                    AreaID: result.length > 0? result[0].areaID: PlaceholderResult[0].areaID,
                    AreaList: result.length > 0? result: PlaceholderResult
                }, () => {
                    this.getBlocks();
                });
            },
            (error) => {
            }
        )
    }
    getBlocks = () =>{
        fetch("https://localhost:44385/property/getAllBlocksByAreaID?AreaID=" + this.state.AreaID)
        .then(res => res.json())
        .then(
            (result) => {
                let PlaceholderResult = [{blockID: -1, blockName: 'Not Available', area: null}];
                this.setState({
                    ...this.state,
                    BlockID: result.length > 0? result[0].blockID: PlaceholderResult[0].blockID,
                    BlockList: result.length > 0? result: PlaceholderResult
                });
            },
            (error) => {
            }
        )
    }
    handle = (e) => {
        e.preventDefault();
        //console.log(e.target.children[0].name);
        this.setState(
            {...this.state, [e.target.name]: e.target.value},
            () => {
                if(e.target.name == "CityID")
                    this.getAreas();
                else if(e.target.name == "AreaID")
                    this.getBlocks();
            }
        );
        
    }
    submit = (e) => {
        e.preventDefault();
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == '' && answer.id != "CNIC"){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }       
        })
        document.querySelectorAll('form select').forEach(answer => {     
            if(answer.value == '-1'){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }            
        })
        document.querySelectorAll('form textarea').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else {
                answer.style.borderColor = '';
            }           
        })
        
        if(!/[0-9]{4}-[0-9]{7}/.test(this.state.MobileNumber) || (this.state.MobileNumber != "" && this.state.MobileNumber.length != 12)){
            document.getElementById("MobileNumberError").style.display = 'block';
            count++;
        }
        else{
            document.getElementById("MobileNumberError").style.display = 'none';
        }
        if(count == 0){
            this.updateProject();
        }
    }

    updateProject = () => {
        
        //console.log(p);
        
        fetch("https://localhost:44385/property/GetAllProjectNamesByBuilderID?BuilderID=" + this.state.BuilderID + "&ProjectID=" + this.props.projectID)
        .then(res => res.json())
        .then(
            async (result) => {
                let count = 0;
                await result.forEach((Project) => {
                    if(Project.projectName == this.state.ProjectName){
                        count = 1;
                        document.getElementById("ProjectNameError").style.display = 'block';
                    }
                })
                if(count == 0){
                    let p = await new BusinessModelParser().MapStateToProject(this.state);
                    p.projectID = this.props.projectID;
                    fetch("https://localhost:44385/property/UpdateProject?json=" + JSON.stringify(p), {
                        method: 'POST'
                    })
                    .then(res => res.json())
                    .then(
                        (result) => {
                        },
                        (error) => {
                            this.setState({...this.state, EditSuccess: true});
                            toast("Project's Information has been Updated");
                        }
                    )
                }
            },
            (error) => {
            }
        )
    }

    render() {
        return (
            <div className="row">
                <ToastContainer />
                <div className="col-lg-8 col-md-10 col-sm-10 col-xs-10 offset-lg-2 offset-md-1 offset-sm-1 offset-xs-1" style={{marginBottom: "40px"}}>
                    <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Edit Project</strong></div>
                    <form onSubmit={this.submit} className="jumbotron" style={{paddingLeft: "60px", paddingRight: "60px"}}>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                                <label htmlFor="ProjectName">Project Name</label>
                                <input id="ProjectName" className="form-control" name="ProjectName" type="text" value={this.state.ProjectName} onChange={this.handle}/>
                                <p style={{color: "red", display: "none"}} id="ProjectNameError">Project Name already exist under selected Builder</p>
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="CityID">City</label>
                                <select id="CityID" className="form-control" name="CityID" onChange={this.handle}>
                                    {
                                        this.state.CityList != null?
                                            this.state.CityList.map((City) =>
                                                <option key={City.cityID} value={City.cityID}>{City.cityName}</option>
                                            ): "Loading"
                                    }
                                </select>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                                <label htmlFor="AreaID">Area</label>
                                <select id="AreaID" className="form-control" name="AreaID" onChange={this.handle}>
                                    {
                                        this.state.AreaList != null?
                                            this.state.AreaList.map((Area) =>
                                                <option key={Area.areaID} value={Area.areaID}>{Area.areaName}</option>
                                            ): <option value="" disabled selected>City is not selcted</option>
                                    }
                                </select>
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="BlockID">Block</label>
                                <select id="BlockID" className="form-control" name="BlockID" onChange={this.handle}>
                                    {
                                        this.state.BlockList != null?
                                            this.state.BlockList.map((Block) =>
                                                <option key={Block.blockID} value={Block.blockID}>{Block.blockName}</option>
                                            ): <option value="" disabled selected>Area is not selected</option>
                                    }
                                </select>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-6">
                                <label htmlFor="BuilderID">Builder</label>
                                <select id="BuilderID" className="form-control" name="BuilderID" onChange={this.handle}>
                                    {
                                        this.state.BuilderList != null?
                                            this.state.BuilderList.map((Builder) =>
                                                <option key={Builder.builderID} value={Builder.builderID}>{Builder.builderName}</option>
                                            ): "Loading"
                                    }
                                </select>
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="MobileNumber">Phone Number</label>
                                <input id="MobileNumber" className="form-control" name="MobileNumber" type="text" value={this.state.MobileNumber} onChange={this.handle}/>
                                <p style={{color: "red", display: "none"}} id="MobileNumberError">Please match the format xxxx-xxxxxxx</p>
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-12">       
                                <label htmlFor="Description">Description</label>
                                <textarea id="Description" name="Description" className="form-control" value={this.state.Description} onChange={this.handle}/>
                            </div>
                        </div>
                        
                        <div className="form-row">   
                            <div className="form-group col-md-6">
                            </div>
                            <div className="form-group col-md-6">
                                <label htmlFor="asd"></label>
                                <input id="asd" className="btn btn-primary" style={{float: "right"}} type="submit" value="Edit Project"/>
                            </div>
                        </div>
                    </form>
                </div>
                {/* {
                    this.state.EditSuccess == true? <EditProjectNavigate></EditProjectNavigate>: <></>
                } */}
            </div>
        );
    }
}

function EditProjectNavigate(){
    let navigate = useNavigate();
    useEffect(()=>{
        navigate("/myprojects");
    }, []);
}

export default EditProject;
