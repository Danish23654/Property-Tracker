import logo from './logo.svg';
import './App.css';
import React, {useState, useContext, useEffect, createRef} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, Route, Switch, Routes, Router, NavLink, useParams, useNavigate } from 'react-router-dom';
import {Builder, Property, BusinessModelParser} from './BusinessModelParser.ts';


class SignUp extends React.Component{
    CNICRef = createRef();
    PasswordRef = createRef();
    ConfirmPasswordRef = createRef();
    EmailAddressRef = createRef();
    MobileNumberRef = createRef();
    constructor(){
        super();
        this.BusinessModelParser = new BusinessModelParser();
        this.state = { 
            FirstName: "",
            LastName: "",
            CNIC: "",
            EmailAddress: "",
            Password: "",
            ConfirmPassword: "",
            ValidCNIC: "",
            MobileNumber: "",
            Created: false,
            IsLoggedIn: localStorage.getItem('UserID') != null && localStorage.getItem('UserID') != ''
        };
    }
    async componentDidMount(){
    }
    handle = (e) => {
        e.preventDefault();
        //console.log(e.target.children[0].name);
        this.setState({...this.state, [e.target.name]: e.target.value},
            () => {
                // if(e.target.name == "CNIC")
                //     this.isCNICExist();
            }
        );
    }

    // isCNICExist = () => {
        
    //     if(this.state.CNIC == "" || (this.state.CNIC != "" && this.state.CNIC.length != 15)){
    //         this.setState({...this.state, ValidCNIC: false });
    //         document.getElementById("CNICExistError").style.display = 'none';
    //         document.getElementById("CNICError").style.display = 'block';
    //     }
    //     else if(/[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.CNIC)){
    //         fetch("https://localhost:44385/property/IsCNICExist?CNIC=" + this.state.CNIC.replace("-", "").replace("-", ""))
    //         .then(res => res.json())
    //         .then(
    //             async (result) => {
    //                 if(result){
    //                     this.setState({...this.state, ValidCNIC: false});
    //                     document.getElementById("CNICExistError").style.display = 'block';
    //                 }
    //                 else if(!result){
    //                     this.setState({...this.state, ValidCNIC: true });
    //                     document.getElementById("CNICExistError").style.display = 'none';
    //                 }
    //                 document.getElementById("CNICError").style.display = 'none';
    //             },
    //             (error) => {
    //             }
    //         )
    //     }
    //     else{
    //         this.setState({...this.state, ValidCNIC: false });
    //         document.getElementById("CNICExistError").style.display = 'none';
    //         document.getElementById("CNICError").style.display = 'block';
    //     }
    // }
    
    submit = (e) => {
        e.preventDefault();
        this.validate(this.state.CNIC, this.state.Password, this.state.ConfirmPassword, this.state.EmailAddress, this.state.MobileNumber);
    }
    async validate(CNIC, Password, ConfirmPassword, EmailAddress, MobileNumber){
        let count = 0;
        document.querySelectorAll('form input').forEach(answer => {     
            if(answer.value == ''){
                answer.style.borderColor = 'red';
                count++;
            }
            else{
                answer.style.borderColor = '';
            }
        })
        if(Password != ConfirmPassword){
            this.PasswordRef.current.style.borderColor = 'red';
            this.ConfirmPasswordRef.current.style.borderColor = 'red';
            document.getElementById("PasswordError").style.display = "block";
            count++;
        }
        else if(Password != ""){
            document.getElementById("PasswordError").style.display = "none";
            this.PasswordRef.current.style.borderColor = '';
            this.ConfirmPasswordRef.current.style.borderColor = '';
        }
        if(!/[0-9]{5}-[0-9]{7}-[0-9]{1}/.test(this.state.CNIC) || (this.state.CNIC != "" && this.state.CNIC.length != 15)){
            document.getElementById("CNICError").style.display = 'block';
            document.getElementById("CNICExistError").style.display = 'none';
            count++;
        }
        else{
            document.getElementById("CNICError").style.display = 'none';
            if(CNIC != "" && true == await this.BusinessModelParser.IsCNICExist(CNIC)){
                count++;
                document.getElementById("CNICExistError").style.display = 'block';
                this.CNICRef.current.style.borderColor = 'red';
            }
            else if(CNIC != ""){
                this.CNICRef.current.style.borderColor = '';
                document.getElementById("CNICExistError").style.display = 'none';
            }
        }
        if(!/[0-9]{4}-[0-9]{7}/.test(this.state.MobileNumber) || (this.state.MobileNumber != "" && this.state.MobileNumber.length != 12)){
            document.getElementById("MobileNumberError").style.display = 'block';
            count++;
        }
        else{
            document.getElementById("MobileNumberError").style.display = 'none';
            if(MobileNumber != ""){
                this.MobileNumberRef.current.style.borderColor = '';
            }
        }
        let IsEmailExist = false;
        await fetch("https://localhost:44385/property/IsEmailExist?EmailAddress=" + EmailAddress)
        .then(res => res.json())
        .then(
            async (result) => {
                //console.log(result);
                IsEmailExist = await result;
            },
            (error) => {
            }
        )
        if(EmailAddress != "" && true == IsEmailExist){
            document.getElementById("EmailAddressError").style.display = "block";
            this.EmailAddressRef.current.style.borderColor = 'red';
            count++;
        }
        else if(EmailAddress != ""){
            document.getElementById("EmailAddressError").style.display = "none";
            this.EmailAddressRef.current.style.borderColor = '';
        }
        if(count == 0){
            this.CreateAccount();
        }
    }
    CreateAccount = () => {
        
        let u = this.BusinessModelParser.MapStateToUser(this.state);
        console.log(u);
        fetch("https://localhost:44385/property/CreateAccount?json=" + JSON.stringify(u), {
            method: 'POST'
        })
        .then(res => res.json())
        .then(
            (result) => {
                localStorage.setItem("UserID", result);
                this.setState({ ...this.state, Created: true});
            },
            (error) => {
            }
        )
    }

    render(){
        return(
            <div className="row">
                <div className="col-lg-8 col-md-8 col-sm-10 col-xs-10 offset-lg-2 offset-md-2 offset-sm-1 offset-xs-1" style={{marginBottom: "40px"}}>
                <div style={{backgroundColor: "#343a40", color: "white", paddingTop: "9px", paddingBottom: "9px", fontSize: "28px", textAlign: "center", marginTop: "40px"}}><strong>Create Account</strong></div>
                <form onSubmit={this.submit} className="jumbotron" style={{paddingLeft: "60px", paddingRight: "60px"}}>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="FirstName">First Name</label>
                            <input id="FirstName" className="form-control" name="FirstName" type="text" value={this.state.FirstName} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="LastName">Last Name</label>
                            <input id="LastName" className="form-control" name="LastName" type="text" value={this.state.LastName} onChange={this.handle}/>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="EmailAddress">Email Address</label>
                            <input id="EmailAddress" ref={this.EmailAddressRef} className="form-control" name="EmailAddress" type="text" value={this.state.EmailAddress} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="EmailAddressError">Email address already exist</p>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="CNIC">CNIC</label>
                            <input id="CNIC" ref={this.CNICRef} className="form-control" name="CNIC" type="text" value={this.state.CNIC} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="CNICExistError">CNIC already exist</p>
                            <p style={{color: "red", display: "none"}} id="CNICError">Please match the format xxxxx-xxxxxxx-x</p>
                        </div>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="Password">Password</label>
                            <input id="Password" ref={this.PasswordRef} className="form-control" name="Password" type="password" value={this.state.Password} onChange={this.handle}/>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="ConfirmPassword">Confirm Password</label>
                            <input id="ConfirmPassword" ref={this.ConfirmPasswordRef} className="form-control" name="ConfirmPassword" type="password" value={this.state.ConfirmPassword} onChange={this.handle}/>
                        </div>
                        <p style={{color: "red", display: "none"}} id="PasswordError">Password and Confirm Password do not match</p>
                    </div>
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="MobileNumber">Mobile Number</label>
                            <input id="MobileNumber" ref={this.MobileNumberRef} className="form-control" name="MobileNumber" type="text" value={this.state.MobileNumber} onChange={this.handle}/>
                            <p style={{color: "red", display: "none"}} id="MobileNumberError">Please match the format xxxx-xxxxxxx</p>
                        </div>
                        <div className="form-group col-md-6">
                            <label htmlFor="asd" style={{ color: "white" }}>sda</label>
                            <input id="asd" className="btn btn-primary col-md-12" type="submit" value="Create Account"/>
                        </div>
                    </div>
                </form>
                {
                    this.state.Created?
                    <>
                        <NavSignUp2></NavSignUp2>
                    </>
                    : this.state.IsLoggedIn?
                    <>
                        <NavSignUp></NavSignUp>
                    </>
                    :
                    <></>
                }

                        {/* <input name="PropertyNumber" type="text" value={this.state.PropertyNumber} onChange={this.handle}/>
                        <input name="NoOfBathrooms" type="number" value={this.state.NoOfBathrooms} onChange={this.handle}/>
                        <input name="NoOfBedrooms" type="number" value={this.state.NoOfBedrooms} onChange={this.handle}/>
                        <input name="Area" type="number" value={this.state.Area} onChange={this.handle}/>
                        <select name="PropertyTypeID" onChange={this.handle}>
                            {
                                this.state.PropertyTypeList != null?
                                    this.state.PropertyTypeList.map((PropertyType) =>
                                        <option key={PropertyType.propertyTypeID} value={PropertyType.propertyTypeID}>{PropertyType.propertyTypeName}</option>
                                    ): "Loading"
                            }
                        </select> */}
                        {/* <input name="Floor" type="number" value={this.state.Floor} onChange={this.handle}/>
                        <input name="Description" type="text" value={this.state.Description} onChange={this.handle}/>
                        <input name="ProjectID" type="text" value={this.state.ProjectID} onChange={this.handle}/>
                        <input name="Price" type="number" value={this.state.Price} onChange={this.handle}/> */}
                        
                </div>
            </div>
        )
    }
}

function NavSignUp() {
    let navigate = useNavigate();
    useEffect(() => {
        navigate("/propertydashboard");
    }, []);
}
function NavSignUp2() {
    let navigate = useNavigate();
    useEffect(() => {
        window.location.reload();
    }, []);
}

export default SignUp;
