﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class Block
    {
        public int? BlockID { get; set; }
        public string BlockName { get; set; }
        public Area Area { get; set; }
    }
}
