﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class PaymentPlanType
    {
        public int? PaymentPlanTypeID { get; set; }
        public string PaymentPlanTypeName { get; set; }
    }
}
