﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class Area
    {
        public int? AreaID { get; set; }
        public string AreaName { get; set; }
        public City City { get; set; }
    }
}
