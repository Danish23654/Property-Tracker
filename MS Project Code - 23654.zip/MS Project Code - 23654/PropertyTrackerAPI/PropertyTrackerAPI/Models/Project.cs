﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class Project
    {
        public int? ProjectID { get; set; }
        public string ProjectName { get; set; }
        public Builder Builder { get; set; }
        public Block Block { get; set; }
        public string Description { get; set; }
        public string MobileNumber { get; set; }
    }
}
