﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class PropertyType
    {
        public int? PropertyTypeID { get; set; }
        public string PropertyTypeName { get; set; }
    }
}
