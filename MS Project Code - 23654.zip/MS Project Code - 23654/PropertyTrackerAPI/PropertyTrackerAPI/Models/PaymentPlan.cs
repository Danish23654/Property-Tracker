﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class PaymentPlan
    {
        public int? PaymentPlanID { get; set; }
        public int? PropertyID { get; set; }
        public int? UserID { get; set; }
        public PaymentPlanType PaymentPlanType {get;set;}
        public int? DownPayment { get; set; }
        public int? LoanAmount { get; set; }
        public int? TotalInstallments { get; set; }
        public int? PaidInstallments { get; set; }
        public int? ActualPrice { get; set; }
        public int? IsActive { get; set; }
    }
}
