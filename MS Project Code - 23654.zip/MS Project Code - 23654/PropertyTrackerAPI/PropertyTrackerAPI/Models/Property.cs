﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PropertyTrackerAPI.Models
{
    public class Property
    {
        public int? PropertyID { get; set; }
        public string PropertyNumber { get; set; }
        public int? NoOfBathrooms { get; set; }
        public int? NoOfBedrooms { get; set; }
        public int? Area { get; set; }
        public PropertyType PropertyType { get; set; }
        public int? Floor { get; set; }
        public string LastModified { get; set; }
        public string DateCreated { get; set; }
        public string Description { get; set; }
        public Project Project { get; set; }
        //AgentID;

        public User User { get; set; }
        public int? Price { get; set; }
        public PaymentPlan PaymentPlan { get; set; }
    }
}
