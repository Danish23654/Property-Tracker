﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using PropertyTrackerAPI.Common;
using PropertyTrackerAPI.Models;
using Microsoft.AspNetCore.Cors;
using System.Net.Http.Json;
using Newtonsoft.Json;

namespace PropertyTrackerAPI.Controllers
{
    public class PropertyController : Controller
    {
        [HttpGet]
        public ActionResult GetAllProperties(int UserID = 0, int CreatedByUserID = 0)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select p.PropertyID, p.PropertyNumber, p.NoOfBathrooms, p.NoOfBedrooms, p.Area, pt.PropertyTypeName, p.Floor,
                p.LastModified, p.DateCreated, p.Description, pr.ProjectName, p.Price, bu.BuilderName, pt.PropertyTypeName,
                b.BlockName, a.AreaName, c.CityName
                from Property p
                JOIN PropertyType pt on(p.PropertyTypeID = pt.PropertyTypeID)
                JOIN Project pr on(p.ProjectID = pr.ProjectID)
                JOIN Builder bu on(bu.BuilderID = pr.BuilderID)
                JOIN Block b on(pr.BlockID = b.BlockID)
                JOIN Area a on(b.AreaID = a.AreaID)
                JOIN City c on(a.CityID = c.CityID)" + (UserID != 0? " JOIN UserLogin u on(u.UserID = p.UserID) where u.UserID = " + UserID: "") + (CreatedByUserID != 0? " Join UserLogin u on(u.UserID = bu.UserID)  where bu.UserID = " + CreatedByUserID: ""));
            List<Property> PropertyList = new List<Property>();
            for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
            {
                Property P = new Property()
                {
                    PropertyID = DataSet.Tables[0].Rows[i]["PropertyID"] as int?,
                    PropertyNumber = DataSet.Tables[0].Rows[i]["PropertyNumber"] as string,
                    NoOfBathrooms = DataSet.Tables[0].Rows[i]["NoOfBathrooms"] as int?,
                    NoOfBedrooms = DataSet.Tables[0].Rows[i]["NoOfBedrooms"] as int?,
                    Area = DataSet.Tables[0].Rows[i]["Area"] as int?,
                    PropertyType = new PropertyType()
                    {
                        PropertyTypeName = DataSet.Tables[0].Rows[i]["PropertyTypeName"] as string
                    },
                    Floor = DataSet.Tables[0].Rows[i]["Floor"] as int?,
                    LastModified = DataSet.Tables[0].Rows[i]["LastModified"] as string,
                    DateCreated = DataSet.Tables[0].Rows[i]["DateCreated"] as string,
                    Description = DataSet.Tables[0].Rows[i]["Description"] as string,
                    Project = new Project()
                    {
                        ProjectName = DataSet.Tables[0].Rows[i]["ProjectName"] as string,
                        Builder = new Builder()
                        {
                            BuilderName = DataSet.Tables[0].Rows[i]["BuilderName"] as string
                        },
                        Block = new Block()
                        {
                            BlockName = DataSet.Tables[0].Rows[i]["BlockName"] as string,
                            Area = new Area()
                            {
                                AreaName = DataSet.Tables[0].Rows[i]["AreaName"] as string,
                                City = new City()
                                {
                                    CityName = DataSet.Tables[0].Rows[i]["CityName"] as string
                                }
                            }
                        }
                    },
                    Price = DataSet.Tables[0].Rows[i]["Price"] as int?
                };
                PropertyList.Add(P);
            }
            return Ok(PropertyList);
        }
        [HttpGet]
        public ActionResult GetPropertyByPropertyID(int PropertyID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select p.PropertyID, p.PropertyNumber, p.NoOfBathrooms, p.NoOfBedrooms, p.Area, pt.PropertyTypeName, p.Floor,
                p.LastModified, p.DateCreated, p.Description, pr.ProjectID, pr.ProjectName, p.Price, bu.BuilderID, bu.BuilderName, pt.PropertyTypeID, pt.PropertyTypeName,
                b.BlockID, b.BlockName, a.AreaID, a.AreaName, c.CityID, c.CityName, u.UserID, u.FirstName, u.LastName, u.CNIC, u.EmailAddress,
                pp.PaymentPlanID, pp.UserID, pp.PaymentPlanTypeID, ppt.PaymentPlanTypeName, pp.DownPayment, pp.LoanAmount, pp.TotalInstallments, pp.PaidInstallments, pp.ActualPrice, pp.IsActive
				from Property p
                JOIN PropertyType pt on(p.PropertyTypeID = pt.PropertyTypeID)
                JOIN Project pr on(p.ProjectID = pr.ProjectID)
                JOIN Builder bu on(bu.BuilderID = pr.BuilderID)
                JOIN Block b on(pr.BlockID = b.BlockID)
                JOIN Area a on(b.AreaID = a.AreaID)
                JOIN City c on(a.CityID = c.CityID)
                LEFT OUTER JOIN PaymentPlan pp on(p.PropertyID = pp.PropertyID and pp.IsActive = 1)
                LEFT OUTER JOIN PaymentPlanType ppt on(pp.PaymentPlanTypeID = ppt.PaymentPlanTypeID)
                LEFT OUTER JOIN UserLogin u on(p.UserID = u.UserID)
                where p.PropertyID = " + PropertyID);
            if (DataSet.Tables[0].Rows.Count > 0)
            {

                return Ok(new Property()
                {
                    PropertyID = DataSet.Tables[0].Rows[0]["PropertyID"] as int?,
                    PropertyNumber = DataSet.Tables[0].Rows[0]["PropertyNumber"] as string,
                    NoOfBathrooms = DataSet.Tables[0].Rows[0]["NoOfBathrooms"] as int?,
                    NoOfBedrooms = DataSet.Tables[0].Rows[0]["NoOfBedrooms"] as int?,
                    Area = DataSet.Tables[0].Rows[0]["Area"] as int?,
                    PropertyType = new PropertyType()
                    {
                        PropertyTypeID = DataSet.Tables[0].Rows[0]["PropertyTypeID"] as int?,
                        PropertyTypeName = DataSet.Tables[0].Rows[0]["PropertyTypeName"] as string
                    },
                    Floor = DataSet.Tables[0].Rows[0]["Floor"] as int?,
                    LastModified = DataSet.Tables[0].Rows[0]["LastModified"] as string,
                    DateCreated = DataSet.Tables[0].Rows[0]["DateCreated"] as string,
                    Description = DataSet.Tables[0].Rows[0]["Description"] as string,
                    Project = new Project()
                    {
                        ProjectID = DataSet.Tables[0].Rows[0]["ProjectID"] as int?,
                        ProjectName = DataSet.Tables[0].Rows[0]["ProjectName"] as string,
                        Builder = new Builder()
                        {
                            BuilderID = DataSet.Tables[0].Rows[0]["BuilderID"] as int?,
                            BuilderName = DataSet.Tables[0].Rows[0]["BuilderName"] as string
                        },
                        Block = new Block()
                        {
                            BlockID = DataSet.Tables[0].Rows[0]["BlockID"] as int?,
                            BlockName = DataSet.Tables[0].Rows[0]["BlockName"] as string,
                            Area = new Area()
                            {
                                AreaID = DataSet.Tables[0].Rows[0]["AreaID"] as int?,
                                AreaName = DataSet.Tables[0].Rows[0]["AreaName"] as string,
                                City = new City()
                                {
                                    CityID = DataSet.Tables[0].Rows[0]["CityID"] as int?,
                                    CityName = DataSet.Tables[0].Rows[0]["CityName"] as string
                                }
                            }
                        }
                    },
                    Price = DataSet.Tables[0].Rows[0]["Price"] as int?,
                    User = new User()
                    {
                        UserID = DataSet.Tables[0].Rows[0]["UserID"] as int?,
                        FirstName = DataSet.Tables[0].Rows[0]["FirstName"] as string,
                        LastName = DataSet.Tables[0].Rows[0]["LastName"] as string,
                        CNIC = DataSet.Tables[0].Rows[0]["CNIC"] as string,
                        EmailAddress = DataSet.Tables[0].Rows[0]["EmailAddress"] as string
                    },
                    PaymentPlan = new PaymentPlan()
                    {
                        PaymentPlanID = DataSet.Tables[0].Rows[0]["PaymentPlanID"] as int?,
                        PropertyID = DataSet.Tables[0].Rows[0]["PropertyID"] as int?,
                        UserID = DataSet.Tables[0].Rows[0]["UserID"] as int?,
                        PaymentPlanType = new PaymentPlanType()
                        {
                            PaymentPlanTypeID = DataSet.Tables[0].Rows[0]["PaymentPlanTypeID"] as int ?,
                            PaymentPlanTypeName = DataSet.Tables[0].Rows[0]["PaymentPlanTypeName"].ToString()
                        },
                        DownPayment = DataSet.Tables[0].Rows[0]["DownPayment"] as int?,
                        LoanAmount = DataSet.Tables[0].Rows[0]["LoanAmount"] as int?,
                        TotalInstallments = DataSet.Tables[0].Rows[0]["TotalInstallments"] as int?,
                        PaidInstallments = DataSet.Tables[0].Rows[0]["PaidInstallments"] as int?,
                        ActualPrice = DataSet.Tables[0].Rows[0]["ActualPrice"] as int?,
                        IsActive = DataSet.Tables[0].Rows[0]["IsActive"] as int?
                    }

                });
            }
            return Ok(new Property());
        }
        [HttpGet]
        public ActionResult GetAllCities()
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select CityID, CityName from City");
            List<City> CityList = new List<City>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    CityList.Add(
                        new City()
                        {
                            CityID = DataSet.Tables[0].Rows[i]["CityID"] as int?,
                            CityName = DataSet.Tables[0].Rows[i]["CityName"].ToString()
                        }
                    );
                }
            }
            return Ok(CityList);
        }

        [HttpGet]
        public ActionResult GetAllAreasByCityID(int CityID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select AreaID, AreaName from Area where CityID = " + CityID);
            List<Area> AreaList = new List<Area>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    AreaList.Add(
                        new Area()
                        {
                            AreaID = DataSet.Tables[0].Rows[i]["AreaID"] as int?,
                            AreaName = DataSet.Tables[0].Rows[i]["AreaName"].ToString()
                        }
                    );
                }
            }
            return Ok(AreaList);
        }

        [HttpGet]
        public ActionResult GetAllBlocksByAreaID(int AreaID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select BlockID, BlockName from Block where AreaID = " + AreaID);
            List<Block> BlockList = new List<Block>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    BlockList.Add(
                        new Block()
                        {
                            BlockID = DataSet.Tables[0].Rows[i]["BlockID"] as int?,
                            BlockName = DataSet.Tables[0].Rows[i]["BlockName"].ToString()
                        }
                    );
                }
            }
            return Ok(BlockList);
        }

        [HttpGet]
        public ActionResult GetAllBuildersByBlockID(int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select b.BuilderID, BuilderName from Builder b join Project p on(b.BuilderID = p.BuilderID) where " + (UserID != 0? " UserID = " + UserID: string.Empty));
            List<Builder> BuilderList = new List<Builder>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    BuilderList.Add(
                        new Builder()
                        {
                            BuilderID = DataSet.Tables[0].Rows[i]["BuilderID"] as int?,
                            BuilderName = DataSet.Tables[0].Rows[i]["BuilderName"].ToString()
                        }
                    );
                }
            }
            return Ok(BuilderList);
        }

        [HttpGet]
        public ActionResult GetAllPropertyTypes()
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select PropertyTypeID, PropertyTypeName from PropertyType");
            List<PropertyType> PropertyTypeList = new List<PropertyType>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    PropertyTypeList.Add(
                        new PropertyType()
                        {
                            PropertyTypeID = DataSet.Tables[0].Rows[i]["PropertyTypeID"] as int?,
                            PropertyTypeName = DataSet.Tables[0].Rows[i]["PropertyTypeName"].ToString()
                        }
                    );
                }
            }
            return Ok(PropertyTypeList);
        }

        public ActionResult GetAllProjectsByBuilder(int BuilderID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select ProjectID, ProjectName from Builder b join Project p on(b.BuilderID = p.BuilderID) where b.BuilderID = " + BuilderID);
            List<Project> ProjectList = new List<Project>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {
                    ProjectList.Add(
                        new Project()
                        {
                            ProjectID = DataSet.Tables[0].Rows[i]["ProjectID"] as int?,
                            ProjectName = DataSet.Tables[0].Rows[i]["ProjectName"].ToString()
                        }
                    );
                }
            }
            return Ok(ProjectList);
        }

        [HttpGet]
        public ActionResult GetPropertyByID(int PropertyID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select p.PropertyID, p.PropertyNumber, p.NoOfBathrooms, p.NoOfBedrooms, p.Area, p.Floor,
                p.LastModified, p.DateCreated, p.Description, pr.ProjectID, pr.ProjectName, p.Price, bu.BuilderID, bu.BuilderName, pt.PropertyTypeID, pt.PropertyTypeName,
                b.BlockID, b.BlockName, a.AreaID, a.AreaName, c.CityID, c.CityName
                from Property p
                JOIN PropertyType pt on(p.PropertyTypeID = pt.PropertyTypeID)
                JOIN Project pr on(p.ProjectID = pr.ProjectID)
                JOIN Builder bu on(bu.BuilderID = pr.BuilderID)
                JOIN Block b on(pr.BlockID = b.BlockID)
                JOIN Area a on(b.AreaID = a.AreaID)
                JOIN City c on(a.CityID = c.CityID) where PropertyID = " + PropertyID);
            return Ok
            (
                new Property()
                {
                    PropertyID = DataSet.Tables[0].Rows[0]["PropertyID"] as int?,
                    PropertyNumber = DataSet.Tables[0].Rows[0]["PropertyNumber"] as string,
                    NoOfBathrooms = DataSet.Tables[0].Rows[0]["NoOfBathrooms"] as int?,
                    NoOfBedrooms = DataSet.Tables[0].Rows[0]["NoOfBedrooms"] as int?,
                    Area = DataSet.Tables[0].Rows[0]["Area"] as int?,
                    PropertyType = new PropertyType()
                    {
                        PropertyTypeID = DataSet.Tables[0].Rows[0]["PropertyTypeID"] as int?,
                        PropertyTypeName = DataSet.Tables[0].Rows[0]["PropertyTypeName"] as string
                    },
                    Floor = DataSet.Tables[0].Rows[0]["Floor"] as int?,
                    LastModified = DataSet.Tables[0].Rows[0]["LastModified"] as string,
                    DateCreated = DataSet.Tables[0].Rows[0]["DateCreated"] as string,
                    Description = DataSet.Tables[0].Rows[0]["Description"] as string,
                    Project = new Project()
                    {
                        ProjectID = DataSet.Tables[0].Rows[0]["ProjectID"] as int?,
                        ProjectName = DataSet.Tables[0].Rows[0]["ProjectName"] as string,
                        Builder = new Builder()
                        {
                            BuilderID = DataSet.Tables[0].Rows[0]["BuilderID"] as int?,
                            BuilderName = DataSet.Tables[0].Rows[0]["BuilderName"] as string
                        },
                        Block = new Block()
                        {
                            BlockID = DataSet.Tables[0].Rows[0]["BlockID"] as int?,
                            BlockName = DataSet.Tables[0].Rows[0]["BlockName"] as string,
                            Area = new Area()
                            {
                                AreaID = DataSet.Tables[0].Rows[0]["AreaID"] as int?,
                                AreaName = DataSet.Tables[0].Rows[0]["AreaName"] as string,
                                City = new City()
                                {
                                    CityID = DataSet.Tables[0].Rows[0]["CityID"] as int?,
                                    CityName = DataSet.Tables[0].Rows[0]["CityName"] as string
                                }
                            }
                        }
                    },
                    Price = DataSet.Tables[0].Rows[0]["Price"] as int?
                }
            );
        }

        [HttpPost]
        public string InsertProperty(string json)
        {
            Property Property = JsonConvert.DeserializeObject<Property>(json);
            SQLConnector obj = new SQLConnector();
            string Query = string.Format(@"insert into Property values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', GetDate(), GetDate(), '{6}', '{7}', {8}, " + (!string.IsNullOrEmpty(Property.User.CNIC)? "(select UserID from UserLogin where CNIC='{9}')": "NULL") + ", '{10}');", Property.PropertyNumber, Property.NoOfBathrooms, Property.NoOfBedrooms, Property.Area, Property.PropertyType.PropertyTypeID, Property.Floor, Property.Description, Property.Project.ProjectID, "NULL", Property.User.CNIC.Replace("-", ""), Property.Price);
            if (!string.IsNullOrEmpty(Property.User.CNIC))
            {
                Query += string.Format(@"insert into PaymentPlan values((SELECT SCOPE_IDENTITY()), " + (!string.IsNullOrEmpty(Property.User.CNIC) ? "(select UserID from UserLogin where CNIC = '{1}')" : "NULL") + ", '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8})",
                    Property.PaymentPlan.PropertyID,
                    Property.User.CNIC.Replace("-", ""),
                    Property.PaymentPlan.PaymentPlanType.PaymentPlanTypeID,
                    Property.PaymentPlan.DownPayment,
                    Property.PaymentPlan.LoanAmount,
                    Property.PaymentPlan.TotalInstallments,
                    Property.PaymentPlan.PaidInstallments,
                    Property.PaymentPlan.ActualPrice,
                    1
                );
            }
            DataSet DataSet = obj.Read(Query);
            return "";
        }

        [HttpPost]
        public string EditProperty(string json)
        {
            Property Property = JsonConvert.DeserializeObject<Property>(json);
            SQLConnector obj = new SQLConnector();
            string Query = string.Empty;
            //DataSet DataSet = obj.Read(string.Format(@"Update Property set PropertyNumber = '{0}', NoOfBathrooms = '{1}', NoOfBedrooms = '{2}', Area = '{3}', PropertyTypeID = '{4}', Floor = '{5}',  LastModified = GetDate(), Description = '{6}', ProjectID = '{7}', AgentID = {8}, " + (!string.IsNullOrEmpty(Property.User.CNIC) ? "UserID = (select UserID from UserLogin where CNIC='{9}')" : "UserID = NULL") + ", Price = '{10}' where PropertyID = {11}", Property.PropertyNumber, Property.NoOfBathrooms, Property.NoOfBedrooms, Property.Area, Property.PropertyType.PropertyTypeID, Property.Floor, Property.Description, Property.Project.ProjectID, "NULL", Property.User.CNIC.Replace("-", ""), Property.Price, Property.PropertyID));
            
            if(Property.PaymentPlan.PaymentPlanID == null && !string.IsNullOrEmpty(Property.User.CNIC))
            {
                //Insert new PaymentPlan
                Query += string.Format(@"insert into PaymentPlan values('{0}', " + (!string.IsNullOrEmpty(Property.User.CNIC) ? "(select UserID from UserLogin where CNIC = '{1}')" : "NULL") + ", '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8})",
                    Property.PaymentPlan.PropertyID,
                    Property.User.CNIC.Replace("-", ""),
                    Property.PaymentPlan.PaymentPlanType.PaymentPlanTypeID,
                    Property.PaymentPlan.DownPayment,
                    Property.PaymentPlan.LoanAmount,
                    Property.PaymentPlan.TotalInstallments,
                    Property.PaymentPlan.PaidInstallments,
                    Property.PaymentPlan.ActualPrice,
                    1
                );
            }
            else if (Property.PaymentPlan.PaymentPlanID != null && !string.IsNullOrEmpty(Property.User.CNIC))
            {
                //Check if CNIC matches with already exist cnic? Update Current Record of PaymentPlan: new Record with new user and mark old record as InActive
                GetPropertyByPropertyID(Property.PropertyID.Value);
            }
            else if (string.IsNullOrEmpty(Property.User.CNIC))
            {
                if(Property.PaymentPlan.PaymentPlanID != null)
                {
                    //Mark IsActive=0 where PaymentPlanID = Property.PaymentPlan.PaymentPlanID
                    Query += string.Format(@"Update PaymentPlan set IsActive = 0 where PaymentPlanID = {0}",
                        Property.PaymentPlan.PaymentPlanID
                    );
                }
            }
            return "";
        }

        [HttpGet]
        public ActionResult GetAllBuilders(int UserID, int BuilderID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet;
            if (UserID == 0)
            {
                DataSet = obj.Read(@"select b.BuilderID, BuilderName from Builder b where BuilderID != "+ BuilderID +" order by BuilderName asc");
            }
            else
            {
                DataSet = obj.Read(@"select b.BuilderID, BuilderName from Builder b where UserID= '"+ UserID +"' order by BuilderName asc");
            }
            List<Builder> BuilderList = new List<Builder>();
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DataSet.Tables[0].Rows.Count; i++)
                {

                    DataSet DataSet1 = obj.Read(@"select ProjectID, ProjectName, BlockName, AreaName, CityName from Project pr
                        JOIN Block b on(pr.BlockID = b.BlockID)
                        JOIN Area a on(b.AreaID = a.AreaID)
                        JOIN City c on(a.CityID = c.CityID) where BuilderID = " + (DataSet.Tables[0].Rows[i]["BuilderID"] as int?) + " order by ProjectName asc");
                    List<Project> Projects = new List<Project>();

                    for (int j = 0; j < DataSet1.Tables[0].Rows.Count; j++)
                    {
                        Projects.Add(
                            new Project()
                            {
                                ProjectID = DataSet1.Tables[0].Rows[j]["ProjectID"] as int?,
                                ProjectName = DataSet1.Tables[0].Rows[j]["ProjectName"].ToString(),
                                Block = new Block()
                                {
                                    BlockName = DataSet1.Tables[0].Rows[j]["BlockName"].ToString(),
                                    Area = new Area()
                                    {
                                        AreaName = DataSet1.Tables[0].Rows[j]["AreaName"].ToString(),
                                        City = new City()
                                        {
                                            CityName = DataSet1.Tables[0].Rows[j]["CityName"].ToString()
                                        }
                                    }
                                }
                            }
                        );
                    }
                    BuilderList.Add(
                        new Builder()
                        {
                            BuilderID = DataSet.Tables[0].Rows[i]["BuilderID"] as int?,
                            BuilderName = DataSet.Tables[0].Rows[i]["BuilderName"].ToString(),
                            Projects = Projects
                        }
                    );
                }
            }
            return Ok(BuilderList);
        }


        [HttpPost]
        public string InsertBuilder(string json)
        {
            Builder Builder = JsonConvert.DeserializeObject<Builder>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"insert into Builder values('{0}', {1}, '{2}', '{3}')", Builder.BuilderName, Builder.User.UserID, Builder.Description, Builder.MobileNumber.Replace("-", "")));

            return "";
        }

        [HttpGet]
        public ActionResult GetBuilderByBuilderID(int BuilderID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select b.BuilderID, BuilderName, Description, MobileNumber from Builder b where BuilderID = " + BuilderID);
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                DataSet DataSet1 = obj.Read(@"select ProjectID, ProjectName, BlockName, AreaName, CityName from Project pr
                    JOIN Block b on(pr.BlockID = b.BlockID)
                    JOIN Area a on(b.AreaID = a.AreaID)
                    JOIN City c on(a.CityID = c.CityID) where BuilderID = " + BuilderID);
                List<Project> Projects = new List<Project>();

                for (int j = 0; j < DataSet1.Tables[0].Rows.Count; j++)
                {
                    Projects.Add(
                        new Project()
                        {
                            ProjectID = DataSet1.Tables[0].Rows[j]["ProjectID"] as int?,
                            ProjectName = DataSet1.Tables[0].Rows[j]["ProjectName"].ToString(),
                            Block = new Block()
                            {
                                BlockName = DataSet1.Tables[0].Rows[j]["BlockName"].ToString(),
                                Area = new Area()
                                {
                                    AreaName = DataSet1.Tables[0].Rows[j]["AreaName"].ToString(),
                                    City = new City()
                                    {
                                        CityName = DataSet1.Tables[0].Rows[j]["CityName"].ToString()
                                    }
                                }
                            }
                        }
                    );
                }
                return Ok(new Builder()
                {
                    BuilderID = DataSet.Tables[0].Rows[0]["BuilderID"] as int?,
                    BuilderName = DataSet.Tables[0].Rows[0]["BuilderName"].ToString(),
                    Description = DataSet.Tables[0].Rows[0]["Description"] as string,
                    MobileNumber = DataSet.Tables[0].Rows[0]["MobileNumber"] as string,
                    Projects = Projects
                });
            }
            return Ok(new Builder());
        }

        public ActionResult GetAllProjects(int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet1;
            if (UserID == 0)
            {
                DataSet1 = obj.Read(@"select ProjectID, ProjectName, BlockName, AreaName, CityName, bu.BuilderID, bu.BuilderName from Project pr
                    JOIN Block b on(pr.BlockID = b.BlockID)
                    JOIN Area a on(b.AreaID = a.AreaID)
                    JOIN City c on(a.CityID = c.CityID)
                    JOIN Builder bu on(bu.BuilderID = pr.BuilderID)
                    order by ProjectName Asc");
            }
            else
            {
                DataSet1 = obj.Read(@"select ProjectID, ProjectName, BlockName, AreaName, CityName, bu.BuilderID, bu.BuilderName from Project pr
                    JOIN Block b on(pr.BlockID = b.BlockID)
                    JOIN Area a on(b.AreaID = a.AreaID)
                    JOIN City c on(a.CityID = c.CityID)
                    JOIN Builder bu on(bu.BuilderID = pr.BuilderID)
                    where bu.UserID = '"+ UserID + @"'
                    order by ProjectName Asc");
            }
            List<Project> Projects = new List<Project>();

            for (int j = 0; j < DataSet1.Tables[0].Rows.Count; j++)
            {
                Projects.Add(
                    new Project()
                    {
                        ProjectID = DataSet1.Tables[0].Rows[j]["ProjectID"] as int?,
                        ProjectName = DataSet1.Tables[0].Rows[j]["ProjectName"].ToString(),
                        Block = new Block()
                        {
                            BlockName = DataSet1.Tables[0].Rows[j]["BlockName"].ToString(),
                            Area = new Area()
                            {
                                AreaName = DataSet1.Tables[0].Rows[j]["AreaName"].ToString(),
                                City = new City()
                                {
                                    CityName = DataSet1.Tables[0].Rows[j]["CityName"].ToString()
                                }
                            }
                        },
                        Builder = new Builder()
                        {
                            BuilderID = DataSet1.Tables[0].Rows[j]["BuilderID"] as int?,
                            BuilderName = DataSet1.Tables[0].Rows[j]["BuilderName"].ToString()
                        }
                    }
                );
            }
            return Ok(Projects);
        }


        [HttpGet]
        public ActionResult GetAllBuilderNamesByUserID(int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select b.BuilderID, BuilderName, Description from Builder b where UserID = " + UserID);
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                List<Builder> Builders = new List<Builder>();
                for (int j = 0; j < DataSet.Tables[0].Rows.Count; j++)
                {
                    Builders.Add(new Builder()
                    {
                        BuilderID = DataSet.Tables[0].Rows[j]["BuilderID"] as int?,
                        BuilderName = DataSet.Tables[0].Rows[j]["BuilderName"].ToString()
                    });
                }
                return Ok(Builders);
            }
            return Ok(new List<Builder>());
        }

        [HttpGet]
        public ActionResult GetAllProjectNamesByBuilderID(int BuilderID, int ProjectID = 0)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select ProjectID, ProjectName from Project  where BuilderID = " + BuilderID + " and ProjectID != " + ProjectID);
            if (DataSet.Tables[0].Rows.Count > 0)
            {
                List<Project> Projects = new List<Project>();
                for (int j = 0; j < DataSet.Tables[0].Rows.Count; j++)
                {
                    Projects.Add(new Project()
                    {
                        ProjectID = DataSet.Tables[0].Rows[j]["ProjectID"] as int?,
                        ProjectName = DataSet.Tables[0].Rows[j]["ProjectName"].ToString()
                    });
                }
                return Ok(Projects);
            }
            return Ok(new List<Project>());
        }

        [HttpPost]
        public string InsertProject(string json)
        {
            Project Project = JsonConvert.DeserializeObject<Project>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"insert into Project values('{0}', {1}, {2}, '{3}', '{4}')", Project.ProjectName, Project.Builder.BuilderID, Project.Block.BlockID, Project.Description, Project.MobileNumber.Replace("-", "")));

            return "";
        }


        [HttpPost]
        public string UpdateProject(string json)
        {
            Project Project = JsonConvert.DeserializeObject<Project>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"Update Project set ProjectName = '{0}', BuilderID = {1}, BlockID = {2}, Description = '{3}', MobileNumber = '{4}' where ProjectID={5}", Project.ProjectName, Project.Builder.BuilderID, Project.Block.BlockID, Project.Description, Project.MobileNumber.Replace("-", ""), Project.ProjectID));

            return "";
        }

        [HttpGet]
        public ActionResult IsCNICExist(string CNIC, int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet;
            if(UserID == 0)
            {
                DataSet = obj.Read(@"select * from UserLogin where CNIC = '" + CNIC + "'");
            }
            else
            {
                DataSet = obj.Read(string.Format(@"select * from UserLogin where CNIC = '{0}' and UserID != {1}", CNIC, UserID));
            }

            return Ok(DataSet.Tables[0].Rows.Count > 0? true: false);
        }

        [HttpGet]
        public ActionResult IsPropertyNameExistInProject(string PropertyNumber, int ProjectID, int PropertyID = 0)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet;
            DataSet = obj.Read(string.Format(@"select * from Property where PropertyNumber = '{0}' and ProjectID = {1} " + (PropertyID != 0? @" and PropertyID != '{2}'": @""), PropertyNumber, ProjectID, PropertyID));
            return Ok(DataSet.Tables[0].Rows.Count > 0 ? true : false);
        }

        [HttpGet]
        public ActionResult IsEmailExist(string EmailAddress, int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet;
            if (UserID == 0)
            {
                DataSet = obj.Read(@"select * from UserLogin where EmailAddress = '" + EmailAddress + "'");
            }
            else
            {
                DataSet = obj.Read(string.Format(@"select * from UserLogin where EmailAddress = '{0}' and UserID != {1}", EmailAddress, UserID));
            }
            return Ok(DataSet.Tables[0].Rows.Count > 0 ? true : false);
        }

        [HttpPost]
        public ActionResult CreateAccount(string json)
        {
            User User = JsonConvert.DeserializeObject<User>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"insert into UserLogin values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", User.FirstName, User.LastName, User.CNIC.Replace("-", ""), User.Password, User.EmailAddress, User.MobileNumber.Replace("-", "")));
            DataSet = obj.Read("Select max(UserID) from UserLogin");

            return Ok(DataSet.Tables[0].Rows[0][0]);
        }


        [HttpPost]
        public ActionResult UpdateAccount(string json)
        {
            User User = JsonConvert.DeserializeObject<User>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"Update UserLogin set FirstName = '{0}', LastName = '{1}', CNIC = '{2}', Password = '{3}', EmailAddress = '{4}', MobileNumber = '{5}' where UserID = {6}", User.FirstName, User.LastName, User.CNIC.Replace("-", ""), User.Password, User.EmailAddress, User.MobileNumber.Replace("-", ""), User.UserID));
            //DataSet = obj.Read("Select max(UserID) from UserLogin");

            return Ok();
        }

        [HttpGet]
        public ActionResult GetUserByUserID(int UserID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select * from UserLogin where UserID = '" + UserID + "'");

            User User = new User()
            {
                UserID = UserID,
                FirstName = DataSet.Tables[0].Rows[0]["FirstName"].ToString(),
                LastName = DataSet.Tables[0].Rows[0]["LastName"].ToString(),
                CNIC = DataSet.Tables[0].Rows[0]["CNIC"].ToString(),
                EmailAddress = DataSet.Tables[0].Rows[0]["EmailAddress"].ToString(),
                Password = DataSet.Tables[0].Rows[0]["Password"].ToString(),
                ConfirmPassword = DataSet.Tables[0].Rows[0]["Password"].ToString(),
                MobileNumber = DataSet.Tables[0].Rows[0]["MobileNumber"].ToString()
            };
            return Ok(User);
        }

        [HttpGet]
        public ActionResult GetUserByCNIC(string CNIC)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(@"select * from UserLogin where CNIC = '" + CNIC + "'");
            if(DataSet.Tables[0].Rows.Count > 0)
            {
                return Ok(new User()
                    {
                        UserID = DataSet.Tables[0].Rows[0]["UserID"] as int?,
                        FirstName = DataSet.Tables[0].Rows[0]["FirstName"].ToString(),
                        LastName = DataSet.Tables[0].Rows[0]["LastName"].ToString(),
                        CNIC = DataSet.Tables[0].Rows[0]["CNIC"].ToString(),
                        EmailAddress = DataSet.Tables[0].Rows[0]["EmailAddress"].ToString(),
                        Password = DataSet.Tables[0].Rows[0]["Password"].ToString(),
                        ConfirmPassword = DataSet.Tables[0].Rows[0]["Password"].ToString()
                    }
                );
            }
            return Ok(new User());
        }

        [HttpGet]
        public ActionResult IsValidLogin(string EmailAddress, string Password)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"select * from UserLogin where EmailAddress = '{0}' and Password = '{1}'", EmailAddress, Password));

            return Ok(DataSet.Tables[0].Rows.Count > 0 ? true : false);
        }

        [HttpGet]
        public ActionResult GetUserIDByEmailAddress(string EmailAddress)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"select * from UserLogin where EmailAddress = '{0}'", EmailAddress));

            return Ok(DataSet.Tables[0].Rows[0]["UserID"]);
        }

        [HttpPost]
        public string UpdateBuilder(string json)
        {
            Builder Builder = JsonConvert.DeserializeObject<Builder>(json);
            SQLConnector obj = new SQLConnector();
            DataSet DataSet = obj.Read(string.Format(@"Update Builder set BuilderName = '{0}', Description = '{1}', MobileNumber = '{2}' where BuilderID={3}", Builder.BuilderName, Builder.Description, Builder.MobileNumber.Replace("-", ""), Builder.BuilderID));

            return "";
        }

        public ActionResult GetProjectByProjectID(int ProjectID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet1 = obj.Read(@"select ProjectID, ProjectName, pr.Description, pr.MobileNumber, b.BlockID, BlockName, a.AreaID, AreaName, c.CityID, CityName, bu.BuilderID, bu.BuilderName from Project pr
                    JOIN Block b on(pr.BlockID = b.BlockID)
                    JOIN Area a on(b.AreaID = a.AreaID)
                    JOIN City c on(a.CityID = c.CityID)
                    JOIN Builder bu on(bu.BuilderID = pr.BuilderID) where pr.ProjectID = " + ProjectID);
            if (DataSet1.Tables[0].Rows.Count > 0)
            {
                return Ok(new Project()
                {
                    ProjectID = DataSet1.Tables[0].Rows[0]["ProjectID"] as int?,
                    ProjectName = DataSet1.Tables[0].Rows[0]["ProjectName"].ToString(),
                    Description = DataSet1.Tables[0].Rows[0]["Description"].ToString(),
                    MobileNumber = DataSet1.Tables[0].Rows[0]["MobileNumber"].ToString(),
                    Block = new Block()
                    {
                        BlockID = DataSet1.Tables[0].Rows[0]["BlockID"] as int?,
                        BlockName = DataSet1.Tables[0].Rows[0]["BlockName"].ToString(),
                        Area = new Area()
                        {
                            AreaID = DataSet1.Tables[0].Rows[0]["AreaID"] as int?,
                            AreaName = DataSet1.Tables[0].Rows[0]["AreaName"].ToString(),
                            City = new City()
                            {
                                CityID = DataSet1.Tables[0].Rows[0]["CityID"] as int?,
                                CityName = DataSet1.Tables[0].Rows[0]["CityName"].ToString()
                            }
                        }
                    },
                    Builder = new Builder()
                    {
                        BuilderID = DataSet1.Tables[0].Rows[0]["BuilderID"] as int?,
                        BuilderName = DataSet1.Tables[0].Rows[0]["BuilderName"].ToString()
                    }
                });
            }
            return Ok(new Project());
        }

        public ActionResult GetPaymentPlanByPropertyID(int PropertyID)
        {
            SQLConnector obj = new SQLConnector();
            DataSet DataSet1 = obj.Read(@"select * from PaymentPlan pp
                Inner Join PaymentPlanType ppt on(pp.PaymentPlanTypeID = ppt.PaymentPlanTypeID)
                where Propertyid = " + PropertyID + " and IsActive = 1");
            if (DataSet1.Tables[0].Rows.Count > 0)
            {
                return Ok(new PaymentPlan()
                {
                    PaymentPlanID = DataSet1.Tables[0].Rows[0]["PaymentPlanID"] as int?,
                    PropertyID = DataSet1.Tables[0].Rows[0]["PropertyID"] as int?,
                    UserID = DataSet1.Tables[0].Rows[0]["UserID"] as int?,
                    PaymentPlanType = new PaymentPlanType()
                    {
                        PaymentPlanTypeID = DataSet1.Tables[0].Rows[0]["PaymentPlanTypeID"] as int?,
                        PaymentPlanTypeName = DataSet1.Tables[0].Rows[0]["PaymentPlanTypeName"].ToString()
                    },
                    DownPayment = DataSet1.Tables[0].Rows[0]["DownPayment"] as int?,
                    LoanAmount = DataSet1.Tables[0].Rows[0]["LoanAmount"] as int?,
                    TotalInstallments = DataSet1.Tables[0].Rows[0]["TotalInstallments"] as int?,
                    PaidInstallments = DataSet1.Tables[0].Rows[0]["PaidInstallments"] as int?,
                    ActualPrice = DataSet1.Tables[0].Rows[0]["ActualPrice"] as int?,
                    IsActive = DataSet1.Tables[0].Rows[0]["IsActive"] as int?
                    
                });
            }
            return Ok(new PaymentPlan());
        }

    }
}
