﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PropertyTrackerAPI.Common
{
    public class SQLConnector
    {
        public DataSet Read(string Query)
        {

            SqlConnection connection = new SqlConnection("data source=.; database=Sample; integrated security=SSPI");
            SqlDataAdapter cmd = new SqlDataAdapter(Query, connection);

            connection.Open();

            DataSet DataSet = new DataSet();
            cmd.Fill(DataSet);

            connection.Close();
            return DataSet;
        }
    }
}
